import java.util.*;
class Automorphic
{
    static Scanner sc = new Scanner(System.in);
    int n,r,cpy,i,m,c,p;
    double s;
    
    public Automorphic()
    {
        n=r=cpy=c=0;
        s=0.0;
    }
    void auto(int a,int b)
    {        
        for(i=a;i<=b;i++)
        {
            c=cpy=p=m=0;
            s = 0.0;
        
            n = i;
            cpy = n;
            m = n * n;
            while(n>0)
            {
                r = n % 10;
                c++;
                n = n / 10;
            }
            s = Math.pow(10,c);
            p = m % (int)s;
            
            if(p==cpy)
                System.out.print(p+",");
        }
    }
    public static void main()
    {
        Automorphic obj = new Automorphic();
        System.out.println("Enter the value of m: ");
        int m = sc.nextInt();
        System.out.println("Enter the value of n: ");
        int n = sc.nextInt();
        
        obj.auto(m,n);        
    }
}
import java.util.*;
class Armstrong
{
    static Scanner sc = new Scanner(System.in);
    int r,n,s,i,cpy; // Data member

    Armstrong() // Default Constructor
    {
        r=0;
        n=0;
        s=0;
        cpy=0;
    }

    void Arms()
    {
        for(i=1;i<=1000;i++) 
        {
            s = 0;    // reset of variable
            n = i;
            cpy = n;             
            while(n>0) 
            {
                r = n % 10;
                s = s + (r * r * r);
                n = n / 10;

            }
            if(s==cpy) 
                System.out.print(s+",");
        }
    }

    public static void main() 
    {
        Armstrong Obj = new Armstrong();  //  Constructor Calling
        System.out.println("Printing Armstrong Numbers till 1000 ");
        Obj.Arms();    // Function Calling 
    }
}
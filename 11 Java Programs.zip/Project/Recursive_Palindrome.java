import java.util.*;
class Recursive_Palindrome
{
    static Scanner sc = new Scanner(System.in);
    int c,r,d;
    public Recursive_Palindrome()
    {
        c=r=d=0;
    }
    int rev(int n)
    {
        if(n>0)
        {
            d = n % 10;
            r = (r * 10)+d;
            return (rev(n/10));
        }
        else
            return r;
    }
    public static void main(String args[])
    {
        int a,x;
        Recursive_Palindrome obj = new Recursive_Palindrome();
        
        System.out.println("Enter the number to check palindrome: ");
        a = sc.nextInt();
        x = obj.rev(a);
        
        if(a == x)
            System.out.println("Its Palindrome Number: "+a);
            else
            System.out.println("Not Plaindrome Number: "+a);
    }
}
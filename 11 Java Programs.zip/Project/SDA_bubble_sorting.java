import java.util.*;
class SDA_bubble_sorting
{
    static Scanner sc = new Scanner(System.in);
    int i,j,temp,n;
    int arr[];
    
    public SDA_bubble_sorting(int x)
    {
        n = x;
        i=j=temp=0;
        arr = new int[n];
    }
    void input()
    {
        System.out.println("Enter the "+n+" elements of array: ");
        for(i=0;i<n;i++)
        {
            arr[i] = sc.nextInt();
        }
    }
    void original()
    {
        System.out.println("The Original array: ");
        for(i=0;i<n;i++)
        {
            System.out.print(arr[i]+",");
        }
        System.out.println();
    }
    void Sort()
    {
        for(i=0;i<(n-1);i++)
        {
            for(j=0;j<(n-i-1);j++)
            {
                if(arr[j]>arr[j+1])
                  {
                      temp = arr[j];
                      arr[j] = arr[j+1];
                      arr[j+1]  = temp;
                  }
            }
        }
    }
    void show()
    {
        System.out.println("The Sorted array in accending order: ");
        for(i=0;i<n;i++)
        {
            System.out.print(arr[i]+",");
        }
    }
    public static void main(String args[])
    {
        int a;
        System.out.println("Enter the size of array: ");
        a = sc.nextInt(); 
       SDA_bubble_sorting obj = new SDA_bubble_sorting(a);
       
       obj.input();
       obj.original();
       obj.Sort();
       obj.show();
    }
}
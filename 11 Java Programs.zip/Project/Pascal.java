import java.util.*;
class Pascal    // Class Name
{
    static Scanner sc = new Scanner(System.in);
    
    int i,j,k,m;      // Data Member
    
    Pascal()
    {
        m = 7;
        i=k=j=0;
    }
    void pasc()         // Member Function
    {
         for(i=1;i<=4;i++)
         {
             for(j=1;j<=m;j++)
             System.out.print(" ");
             for(k=1;k<=i;k++)
             System.out.print(k+" ");
             for(k=i-1;k>=1;k--)
             System.out.print(k+" ");
             System.out.println();
             m = m - 2;
         }
         m=3;
         for(i=3;i>=1;i--)
         {
             for(j=1;j<=m;j++)
             System.out.print(" ");
             for(k=1;k<=i;k++)
             System.out.print(k+" ");
             for(k=i-1;k>=1;k--)
             System.out.print(k+" ");
             System.out.println();
             m = m + 2;
         }
    }    
    public static void main()
    {
        Pascal obj = new Pascal();
        System.out.println("Printing the Pascal's Triangle! ");
        obj.pasc();
    }
}
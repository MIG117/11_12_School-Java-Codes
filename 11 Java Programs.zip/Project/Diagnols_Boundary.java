import java.util.*;
class Diagnols_Boundary
{
    static Scanner sc = new Scanner(System.in);
    int i,j,m,n,arr[][];
    
    public Diagnols_Boundary(int mm,int nn)
    {
       i=j=0;
       m = mm;
       n = nn;
       arr = new int[m][n];
    }
    void input()
    {
        System.out.println("Enter the elements in array: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    void Ldiagnol()
    {
        System.out.println("Printing Left Diagnol: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                if(i==j)
                    System.out.print(arr[i][j]+" ");
                else
                    System.out.print("   ");
            }
            System.out.println();
        }        
    }
    void Rdiagnol()
    {
       System.out.println("Printing Right Diagnol: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                if(i+j==m-1)
                    System.out.print(arr[i][j]+" ");
                else
                    System.out.print("   ");
            }
            System.out.println();
        }         
    }
    void boundary()
    {
        System.out.println("Printing Diagnol: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                if((i==0) || (i==m-1) || (j==0) || (j==m-1))
                    System.out.print(arr[i][j]+" ");
                else
                    System.out.print("  ");
            }
            System.out.println();
        }        
    }
    public static void main()
    {
        int a,b,x;
        System.out.println("Enter the size of m: ");
        a = sc.nextInt();
        System.out.println("Enter the size of n: ");
        b = sc.nextInt();
        
        Diagnols_Boundary obj = new Diagnols_Boundary(a,b);
        obj.input();
        
        
        System.out.println("1. Right Diagnol");
        System.out.println("2. Left Diagnol");
        System.out.println("3. Boundry");
        System.out.println("Enter your choice: ");
        x = sc.nextInt();
        
        switch(x)
        {
            case 1: obj.Rdiagnol();
            break;
            case 2: obj.Ldiagnol();
            break;
            case 3: obj.boundary();
            break;
            default: System.out.println("Invalid Input! ");
        }
    }
}
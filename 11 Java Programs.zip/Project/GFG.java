import java.io.*; 
  
class GFG  
{     
    static int hexadecimalToDecimal(String hVal) 
    {    
        int i,l,b1=1,dv=0;   
        l = hVal.length();  // Initializing base value to 1, i.e 16^0 
        
        for ( i=(l-1);i>=0;i--) // Extracting characters as digits from last character
        {    
            // if character lies in '0'-'9', converting  
            // it to integral 0-9 by subtracting 48 from 
            // ASCII value 
            if (hVal.charAt(i) >= '0' && hVal.charAt(i) <= '9') 
            { 
                dv = dv + (hVal.charAt(i)-48)*b1;    // incrementing base by power                                 
                b1 = b1 * 16; 
            } 
   
            // if character lies in 'A'-'F' , converting  
             
            else if (hVal.charAt(i) >= 'A' && hVal.charAt(i) <= 'F') 
            { 
               dv = dv + (hVal.charAt(i) - 55)*b1;    // it to integral 10 - 15 by subtracting 55  from ASCII value                          
                b1 = b1 * 16; // incrementing base by power 
            } 
        } 
        return dv; 
    }        
    public static void main (String[] args)  
    { 
        String hexNum = "7CE";     
        System.out.println(hexadecimalToDecimal(hexNum)); 
    } 
} 
  
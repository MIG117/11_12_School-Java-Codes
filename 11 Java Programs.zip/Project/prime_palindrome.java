import java.util.*;
class prime_palindrome
{
    static Scanner sc = new Scanner(System.in);
    int i,j,n,r,s,c,p,cpy;    // Data Member
    
    prime_palindrome() // Default Constructor
    {
        r = 0;
        s = 0;
        c = 0;
        p = 0;
        cpy = 0;
    }
    int isprime(int nn) // Member Function
    {
        n = nn;
        c = 0; // reset
        for(i=1;i<=n;i++)
        {
            if(n%i==0)
                c++;
        }
        if(c==2)
            return 1;
        else
            return 0;
    }
    int ispalin(int pp) // Member Function
    {
             p=pp;
             cpy = p; // copying to cpy
            s = 0;  // reset
        while(p>0)
        {
            r = p                                                                                                       % 10;
            s = (s * 10) + r;
            p = p / 10;
        }
        if(s==cpy)
            return 1;
        else
            return 0;
    }
    public static void main() // main method
    {
        prime_palindrome obj = new prime_palindrome(); // Default Constructor
        System.out.println("Enter the range of m: ");
        int m = sc.nextInt();
        System.out.println("Enter the range of n: ");
        int n = sc.nextInt();
                        
        for(int j=m;j<=n;j++)
        {
            int a = obj.isprime(j); // Function Calling
            int b = obj.ispalin(j);
            if(a==1 && b==1)
                System.out.print(j+" ");
        }
    }
}
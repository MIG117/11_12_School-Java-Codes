import java.util.*;
class SDA_Duplicate
{
       static Scanner sc = new Scanner(System.in);
       int i,n,j;        // Data Member 
       int a[],b[];  
      
       SDA_Duplicate(int nn)   // Parameterised Constructor 
     {
        n = nn;
        a = new int[n];
        b = new int[n];
     }
     void input()               // Member Function
      {
        System.out.println("Enter "+n+" element in array: ");
        for(i=0;i<n;i++)
         {
            a[i] = sc.nextInt();
         }
      }
     void dup()         // Member Function
     {
       for(i=0;i<n;i++)
        {
          for(j=i+1;j<n;j++)
             {
                if(a[i]==a[j])
                    a[j]=0;
             }
        }     
                j=0;
       for(i=0;i<n;i++)
       {
           if(a[i]!=0)
           {
               b[j] = a[i];
               j=j+1;
           }
       }
     }
     void show()     // Member Function
     {
       System.out.println("The result after removing duplicate: ");
       for(i=0;i<j;i++)
            System.out.print(b[i]+"");
     }
     public static void main(String args[]) // main method
     {
       int s;   // local variable
       
       System.out.println("Enter the size of the array: ");      
       s = sc.nextInt();
       
       SDA_Duplicate obj = new SDA_Duplicate(s); // Constructor Calling
       obj.input();              // Function Calling
       obj.dup();
       obj.show();
     }
}
import java.util.*;
class Palindrome_word
{
    static Scanner sc = new Scanner(System.in);
    int i,l;
    String str="",cp,str2="";
    char ch;
    
    public Palindrome_word()
    {
        i=l=0;
        str=cp="";
        ch = ' ';
    }
    void input()
    {
        System.out.println("Enter the word: ");
        str = sc.nextLine();
        str = str.toUpperCase();
        l = str.length();
    }
    boolean pal()
    {
        for(i=(l-1);i>=0;i--)
        {
            ch = str.charAt(i);
            str2 = str2 + ch;
        }
        if(str.equals(str2))
            return true;
        else
            return false;
    }
    void show(boolean x)
    {
        if(x==true)
            System.out.println("Its Palindrome Word: "+str2);
        else
            System.out.println("Not Palindrome Word: "+str2);
    }
    public static void main(String args[])
    {
        boolean a;
        Palindrome_word obj = new Palindrome_word();
        
        obj.input();
        a = obj.pal();     
        obj.show(a);
    }
}
import java.util.*;
class DDA_mirror_img
{
    static Scanner sc = new Scanner(System.in);
    int arr[][];
    int i,j,m,n;

    public DDA_mirror_img(int x,int y)
    {
        m = x;
        n = y;       
        arr = new int[m][n];
    }
    void input()
    {
        System.out.println("Enter the elements in array: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    void mirror()
    {
        System.out.println("The mirror array: ");
        for(i=0;i<m;i++)
        {
            for(j=m-1;j>=0;j--)
            {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    void show()
    {
        System.out.println("The original array: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void main(String args[])
    {
        int a,b,s=0;
        
        System.out.println("Enter the size of m: ");
        a = sc.nextInt();
        System.out.println("Enter the size of n: ");
        b = sc.nextInt();
        
        DDA_mirror_img obj = new DDA_mirror_img(a,b);
        obj.input();
        obj.show();
        obj.mirror();
    }
}
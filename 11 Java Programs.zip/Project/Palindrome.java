import java.util.*;
class Palindrome 
{
    static Scanner sc = new Scanner(System.in);
    int cpy=0,s=0,i,r,n;
    static int p=0;
    int is_pal(int nn) 
    {
        cpy=nn;
        while(nn>0) 
        {
            r = nn % 10;
            s = (s * 10)+r;
            nn = nn / 10;
        }
        if(s==cpy) 
        {
            p = s;
            return 1;
        }   
        else 
        {
            p = s;
            return 0;            
        }    
    }
    public static void main() 
    {
            Palindrome obj = new Palindrome();
            System.out.println("Enter a Number to check for Palindrome: ");
            int x = sc.nextInt();
            
            int y = obj.is_pal(x);
            
            if(y==1)
                System.out.println("Number is Palindrome: "+p);
            else
                System.out.println("Number is not Palindrome: "+p);
    }
}
import java.util.*;
class DDA_Sorting
{
    static Scanner sc = new Scanner(System.in);
    int i,j,k,t,m,n;
    int arr[][]; 
        
    public DDA_Sorting(int x,int y)
    {
        i=j=k=t=0;
        m = x;
        n = y;
        arr = new int [m][n];
    }
    void input()
    {
        System.out.println("Enter the elements in "+m+" & "+n+" matrix: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    void sort()
    {
        for(i=0;i<m;i++)
        {
            for(j=0;j<n-1;j++)
            {
                for(k=0;k<(m-1-j);k++)
                {
                    if(arr[i][k]>arr[i][k+1])
                    {
                        t = arr[i][k];
                        arr[i][k] = arr[i][k+1];
                        arr[i][k+1] = t;
                    }
                }
            }
        }
    }
    void show()
    {
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                System.out.print(arr[i][j]+" "); 
            }
            System.out.println("");
        }
    }
    public static void main(String args[])
    {
        int a,b;
                
        System.out.println("Enter the m value of matrix: ");
        a = sc.nextInt();
        System.out.println("Enter the n value of matrix: ");
        b = sc.nextInt();
        
        DDA_Sorting obj = new DDA_Sorting(a,b);
        
        obj.input();
        System.out.println("Original Array: ");
        obj.show();
        obj.sort();
        System.out.println("Sorted Array in accending order: ");
        obj.show();
    }
}
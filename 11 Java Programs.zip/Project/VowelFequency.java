import java.util.*;
class VowelFequency
{   
   static Scanner in = new Scanner(System.in);
     int l,i,a,b,c,d,e;
     char ch;
     String str;

    public VowelFequency()
   {
        i=l=a=b=c=d=e=0;
        ch = ' ';
        str = " ";

   }
   void input()
   {
       System.out.println("Enter the String to count the fequency: ");
        str = in.nextLine();
   }
   void fequency()
   {
       
         str = str.toUpperCase();
          l = str.length();
        for(i=0;i<l;i++)
        {
            ch = str.charAt(i);
                if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
                    c++;
        }
   }
   void show()
   {
        System.out.println("Frequency of Vowel: "+c);        
   }
   static void main()
    {   
        VowelFequency obj = new VowelFequency();
        
        obj.input(); 
        obj.fequency();
        obj.show();
    }
}
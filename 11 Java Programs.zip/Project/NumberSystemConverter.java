import java.util.*;
class NumberSystemConverter 
{
    static Scanner sc = new Scanner(System.in);
    int c,n,r,i;
    double d;
    String str="";
    
    public NumberSystemConverter()
    {
        i=c=n=r=0;
        d = 0.0;
        str = "";
    }
    void DecToBin()
    {
        
        System.out.println("Enter the decimal value: ");
        n = sc.nextInt();
        while(n>0)
        {
            r = n % 2;
            str = Integer.toString(r)+str;
            n = n / 2;
        }
        System.out.println("The binary eqivalent: "+str);
    }
    void BinToDec()
    {
        System.out.println("Enter the binary value: ");
        n = sc.nextInt();
        while(n>0)
        {
            r = n % 10;
            d = d + r * Math.pow(2,c);
            n = n / 10;
              c++;
        }
        System.out.println("The decimal equivalent: "+(int)d);
    }
    void DecToOct()
    {
        int z1=0;
        int i = 0;      // counter for octal number array
        int oc[] = new int[100];      // array to store octal number 
        System.out.println("Enter the decimal value: ");
        n = sc.nextInt();
                                      
        while(n>0)  
        {            
            oc[i] = n % 8;  // storing remainder in octal array 
            n = n / 8; 
            i++; 
        }           
        for (int j = i - 1; j >= 0; j--) // Printing octal number array in reverse order 
            z1 = z1 * 10 + oc[j];
        System.out.println("The octal eqivalent: "+z1);
    }
    void OctToDec()
    {
        System.out.println("Enter the octal value: ");
        n = sc.nextInt();
        while(n>0)
        {
            r = n % 10;
            d = d + r * Math.pow(8,c);
            n = n / 10;
              c++;
        }
        System.out.println("The decimal equivalent: "+(int)d);
    }
    void DecToHex()
    {        
        int arr[] = new int[20];
        
        System.out.println("Enter the decimal value: ");
        n = sc.nextInt();        
        while(n>0)
        {
            r = n % 16;
            arr[i] = r;
            n = n / 16;
            i++;  
            c++;
        }
        for(i=c-1;i>=0;i--)
        {
            if((arr[i]>=10) && (arr[i]<=15))
            {
                if(arr[i]==10)
                System.out.print("A");
                if(arr[i]==11)
                System.out.print("B");
                if(arr[i]==12)
                System.out.print("C");
                if(arr[i]==13)
                System.out.print("D");
                if(arr[i]==14)
                System.out.print("E");
                if(arr[i]==15)
                System.out.print("F");
            }
            else
            System.out.print(arr[i]);
        }
        System.out.println();
    }
    void HexToDec()
    {
        int i,l,b1=1,dv=0;
        
        System.out.println("Enter the hexadecimal value: ");
        str = sc.nextLine();
        str = str.toUpperCase();
        l = str.length();  // Initializing base value to 1, i.e 16^0         
        for ( i=(l-1);i>=0;i--) // Extracting characters as digits from last character
        {                
            if (str.charAt(i) >= '0' && str.charAt(i) <= '9') 
            { 
                dv = dv + (str.charAt(i)-48)*b1;    // incrementing base by power                                 
                b1 = b1 * 16; 
            }                             
            else if (str.charAt(i) >= 'A' && str.charAt(i) <= 'F') // if character lies in 'A'-'F' , converting  
            { 
               dv = dv + (str.charAt(i) - 55)*b1;    // it to integral 10 - 15 by subtracting 55  from ASCII value                          
               b1 = b1 * 16;                            // incrementing base by power 
            } 
        } 
            System.out.println("The Decimal equivalent: "+dv); 
    }
    public static void main(String args[])
    {
        NumberSystemConverter obj = new NumberSystemConverter();
        int s;
        System.out.println("Number System Converter ");
        System.out.println("1. Decimal to Binary ");
        System.out.println("2. Binary to Decimal ");
        System.out.println("3. Decimal to Octal  ");
        System.out.println("4. Octal to Decimal  ");
        System.out.println("5. Decimal to Hexadecimal");
        System.out.println("6. Hexadecimal to Decimal");
        System.out.println("Enter your conversion choice: ");
        s = sc.nextInt();
        switch(s)
        {
            case 1: obj.DecToBin();
            break;
            case 2: obj.BinToDec();
            break;
            case 3: obj.DecToOct();
            break;
            case 4: obj.OctToDec();
            break;
            case 5: obj.DecToHex(); 
            break;
            case 6: obj.HexToDec();
            break;
            default: System.out.println("Invalid Input! ");
        }
    }
}
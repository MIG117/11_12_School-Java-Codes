import java.util.*;
class DDA_Multiply
{
    static Scanner sc = new Scanner(System.in);    
    int i,j,m,n,cpy,k;
    int num[][]; 
    int num2[][];
    int num3[][];    
    DDA_Multiply(int x,int y)
    {
        m = x;
        n = y;
        i=j=cpy=k=0;
        num = new int[m][n];
        num2 = new int[m][n];
        num3 = new int[m][n];
    }
    void input() 
    {
        System.out.println("Enter the element in 1st array: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                num[i][j] = sc.nextInt();
            }
        }
        System.out.println("Enter the element in 2nd array: ");
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                num2[i][j] = sc.nextInt();
            }
        }
    }
    void multi() 
    {
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                num3[i][j] = 0;
                for(k=0;k<n;k++)
                {
                    num3[i][j] = num3[i][j] + num[i][k] * num2[k][j];
                }
            }
        }
    }
    void show() 
    {
        System.out.println("The Multiplication of 2 matrix: ");        
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                System.out.print(num3[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void main()
    {
        int a,b;
        System.out.println("Enter the size of m: ");
        a = sc.nextInt();
        System.out.println("Enter the size of n: ");
        b = sc.nextInt();
        DDA_Multiply obj = new DDA_Multiply(a,b);
        obj.input();
        obj.multi();
        obj.show();
    }
}
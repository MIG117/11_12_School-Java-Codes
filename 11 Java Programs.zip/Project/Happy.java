import java.util.*;
class Happy
{
    static Scanner sc = new Scanner(System.in);
    int r,s,n,cpy;
    public Happy()
    {
        r=s=n=cpy=0;
    }
    void input()
    {
        System.out.println("Enter a number to check happy num or not: ");
        n = sc.nextInt();
        cpy=n;
    }
    int ishappy()
    {
         while(n>9)
        {
            s = 0;
            while(n>0)
            {
                r = n % 10;
                s = s + r * r;
                n = n / 10;
            }
            n = s;
        }
        if(n==1)
             return 1;           // System.out.println("The number is happy: "+cpy);
        else
             return 0;                   // System.out.println("The number is not happy: "+cpy);
    }
    public static void main()
    {
        int x;
        Happy obj = new Happy();
        
        obj.input();
        x = obj.ishappy();
        
        if(x==1)
            System.out.println("Its a Happy Number ");
        else
            System.out.println("Its not Happy Number ");
    }
}
import java.util.*;
class Encryption
{
    static Scanner sc = new Scanner(System.in);
    String str;
    String str1;
    
    public Encryption()
    {
        str = "";
        str1 = "";
    }
    void input()
    {
        System.out.println("Enter the String to be encrypted: ");
        str = sc.nextLine();
    }
    void encrypt()
    {
        int i,l,p=0;
        char ch;
        
        l = str.length();
        for(i=0;i<l;i++)
        {
            ch = str.charAt(i);
            
            if(ch>='a' && ch<='y' || ch>='A' && ch<='Y')
            {
                if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
                {
                    p = (int)ch + 2;
                    ch = (char)p;
                }
                else 
                {
                    p = (int)ch + 1;
                    ch = (char)p;
                }
            }
            else if(ch=='z'|| ch=='Z')
            {
                p = (int)ch - 25;
                ch = (char)p;
            }
            str1 = str1 + ch;
        }
    }
    void display()
    {
        System.out.println("Original: "+str);
        System.out.println("Encrypted: "+str1);
    }
    public static void main()
    {
        Encryption obj = new Encryption();
        
        obj.input();
        obj.encrypt();
        obj.display();
    }
}    
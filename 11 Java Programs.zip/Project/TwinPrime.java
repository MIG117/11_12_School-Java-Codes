import java.util.*;
class TwinPrime
{
    static Scanner sc = new Scanner(System.in);
    int n;
    
    public TwinPrime()
    {
        n = 0;
    }
    boolean isprime(int x)
    {
        n = x;
        int i,c=0;
        for(i=1;i<=n;i++)
        {
            if(n%i==0)
            {
                c++;
            }
        }
        if(c==2)
            return true;
        else
            return false;
    }
    void display()
    {
        System.out.println("Both the number are twin prime");
    }
    public static void main(String args[])
    {
        TwinPrime obj = new TwinPrime();
        
        System.out.println("Enter the first number: ");
        int a = sc.nextInt();
        System.out.println("Enter the second number: ");
        int b = sc.nextInt();
        
        boolean x = obj.isprime(a);
        boolean y = obj.isprime(b);
        if((x==true && y==true)&&(a-b==2 || b-a==2))
            obj.display();
        else
            System.out.println("Both are not Twin Prime");
    }    
}
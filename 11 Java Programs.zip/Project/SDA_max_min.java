/** WAP to find the maximum & minimum element of SDA of size 10 */
import java.util.*;
class SDA_max_min
{
    static Scanner sc = new Scanner(System.in);
        int i,j,max,min,n,cpy;
        int arr[];
    public SDA_max_min(int nn)
    {
         cpy=nn;
         i=j=max=min=n=0;
         arr = new int[nn];
    }
    void input()
    {
        System.out.println("Enter the Number: ");
        for(i=0;i<cpy;i++) {
           arr[i] = sc.nextInt();
        }
    }
    void max()
    {
        max = arr[0];
        for(j=0;j<cpy;j++) 
        {
            if(max<arr[j])
                max = arr[j];              
        }
    }
    void min()
    {
        min = arr[0];
        for(j=0;j<cpy;j++) 
        {   
            if(min>arr[j])
                min = arr[j];
        }
    }
    void show()
    {
        System.out.println("The greatest element of the array: "+max);
        System.out.println("The lowest element of the array: "+min); 
    }
    public static void main() 
    {
        int n1;
       System.out.println("Enter the size of array: ");
       n1 = sc.nextInt();
       SDA_max_min obj = new SDA_max_min(n1);
       
       obj.input();
       obj.max();
       obj.min();
       obj.show();
    }
}
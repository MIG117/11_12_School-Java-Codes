import java.util.*;
class Fibonaci_Recursive
{
    static Scanner sc = new Scanner(System.in);
    
    int fibseries(int num)
    {
        if(num==1)
            return 0;
        else if(num==2)
            return 1;
        else if(num>2)
                return(fibseries(num-1)+fibseries(num-2));
        else 
            return -1;
    }
    public static void main(String args[])
    {
        int n,i,t=0;
        
        System.out.println("Enter number of terms: ");
        n = sc.nextInt();
        
        Fibonaci_Recursive obj = new Fibonaci_Recursive();
        
        System.out.println("Fibonacci Series using recursion: ");
        for(i=1;i<=n;i++)
        {
            t = obj.fibseries(i);
            System.out.print(t+",");
        }
    }
}
import java.util.*;
class WordCombination    
{
    static Scanner sc = new Scanner(System.in);
    int i,j,k,l;
    String str;       // Data Members
    char ch;
    WordCombination() // Default constructor
    {
        i=0;
        j=0;
        k=0;
        str="";
    }
    void input()
    {
       System.out.println("Enter the word to print its combination: ");
        str = sc.next();
    }
    void combination()  // Member Function
    {
        str = str.toUpperCase();
        l = str.length(); // length of String         
        for(i=0;i<l;i++)
        {
            for(j=0;j<l;j++)
            {
                for(k=0;k<l;k++)
                {
                    if(i!=j && j!=k && k!=i)
                    
                        System.out.print(str.charAt(i)+" "+str.charAt(j)+" "+str.charAt(k));                    
                }
                System.out.println();
            }
        }
    }
    public static void main() // Main Method
    {
        WordCombination obj = new WordCombination();
        obj.input();
        obj.combination();        
    }
}
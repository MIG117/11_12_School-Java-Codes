import java.util.*;
class binaryconversion
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,r;
        String  d=" ";
        System.out.println("Enter any Nummber");
        n=sc.nextInt();
        while(n>0)
        {
            r=n%2;
            d=Integer.toString(r)+d;
            n=n/2;
        }
        System.out.println("The Binary Equivalent ="+d);
    }
}

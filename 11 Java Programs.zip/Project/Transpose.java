import java.util.*;
class Transpose
{
    static Scanner sc = new Scanner(System.in);
        int arr[][];
        int num [][];
        int i,j,m,n,p;
    public Transpose(int m1,int n1)
    {
        arr = new int[m1][n1];
        num = new int[m1][n1];
        p = m1;
    }
    void input()
    {
        
        
        System.out.println("Enter the element of the array: ");
        for(i=0;i<p;i++)
        {
            for(j=0;j<p;j++) 
            {
                arr[i][j] = sc.nextInt();
            }
        }   
    }
    void trans()
    {
         for(i=0;i<p;i++)
        {
            for(j=0;j<p;j++) 
            {
                num[j][i] = arr[i][j];
            }
        }
        System.out.println("Transposed Matrix");
        for(i=0;i<p;i++)
        {
            for(j=0;j<p;j++) 
            {
                System.out.print(num[i][j]+" ");
            }
            System.out.println(" ");
        }   
    }
    
    void original()
    {
        System.out.println("Original Matrix");
        for(i=0;i<p;i++)
        {
            for(j=0;j<p;j++) 
            {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println(" ");
        }   
    }   
    public static void main()
    {     
        int m,n;
        System.out.print("Enter the size of m: ");
        m = sc.nextInt();
        System.out.print("Enter the value of n: ");
        n = sc.nextInt();
        
        Transpose obj = new Transpose(m,n);
        
        obj.input();
        obj.original();
        obj.trans();
        
    }
}
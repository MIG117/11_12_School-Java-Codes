import java.io.*;
class linklist
{
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    Node head;
    linklist()
    {
        head = null;
    }
    
    void append()throws IOException//push
    {
        Node p = new Node(),q;
        System.out.println("Enter Date : ");
        p.d = Integer.parseInt(br.readLine());
        p.link = null;
        if(head==null)
        {
            head = p;
            return;
        }
        q=head;
        while(q.link!=null)
        {
            q=q.link;
        }
        q.link = p;
    }
    
    void add_beg()throws IOException
    {
        Node p = new Node();
        System.out.println("Enter a value : ");
        p.d = Integer.parseInt(br.readLine());
        if(head==null)
        {
            head = p;
            p.link = null;
            return;
        }
        p.link = head;
        head = p;
    }
    
    void delete_end()
    {
        if(head==null)
        {
            System.out.println("Linked list is empty");
            return;
        }
        
        if(head.link==null)
        {
            System.out.println("Deleted Note : "+head.d);
            head=null;
            return;
        }
        
        Node q =head.link, r=head;
        while(q.link!=null)
        {
            r=r.link;
            q=q.link;
        }
        System.out.println("deleted value"+q.d);
        r.link=null;
    }
    
    void delete_beg()
    {
        if(head==null)
        {
            System.out.println("Cannot delete");
            return;
        }
        System.out.println("Deleted value = "+head.d);
        head=head.link;
    }
    
    int count()
    {
        Node q = head;
        int c = 0;
        while(q!=null)
        {
            q=q.link;
            c++;
        }
        return c;
    }
    
    void add_any_pos()throws IOException
    {
        Node p = new Node(), q;
        int c,x, pos;
        System.out.println("Enter the position where u want to enter the Node : ");
        pos = Integer.parseInt(br.readLine());
        c=count();
        if(pos<1||pos>c+1)
        {
            System.out.println("Invalid Position");
            return;
        }
        System.out.println("Enter a value : ");
        x=Integer.parseInt(br.readLine());
        p.d=x;
        if(pos==1)
        {
            if(head==null)
            {
                head = p;
                p.link = null;
                return;
            }
            p.link = head;
            head = p;
            return;
        }
        int i;
        q=head;
        for(i=2;i<pos;i++)
        {
            q=q.link;
        }
        p.link = q.link;
        q.link = p;
    }
    
    void del_any_pos()throws IOException
    {
        Node r, q;
        if(head==null)
        {
            System.out.println("Nothing to delete");
            return;
        }
        
        int x, pos, c,i;
        System.out.println("Enter the position where u want to delete the Node : ");
        pos = Integer.parseInt(br.readLine());
        c=count();
        if(pos<1||pos>c)
        {
            System.out.println("Invalid Position");
            return;
        }
    }
}
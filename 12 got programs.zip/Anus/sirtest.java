import java.util.*;
class sirtest
{
    static Scanner sc = new Scanner(System.in);
    int i,j,n;
    char a,b,c,M[][];

    sirtest(int nn)
    {
        n=nn;
        M=new char[n][n];
    }

    void input()
    {
        System.out.println("Enter the 1st Character : ");
        a=sc.next().charAt(0);
        System.out.println("Enter the 2st Character : ");
        b=sc.next().charAt(0);
        System.out.println("Enter the 3st Character : ");
        c=sc.next().charAt(0);
    }

     void calculate()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                if((i==j)||(i+j)==(n-1))
                {
                    M[i][j] = c;
                }
                else if(i==0||i==n-1)
                {
                    if(j!=0||j!=n-1)
                    {
                        M[i][j] = a;
                    }
                }
                else
                {
                    M[i][j] = b;
                }
            }
        }
    }
    
    void display()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                System.out.print(M[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main()
    {
        System.out.print("Enter the Limit : ");
        int n = sc.nextInt();
        if(n>0&&n<10)
        {
            sirtest s = new sirtest(n);
            s.input();
            s.calculate();
            s.display();
        }
        else
        {
            System.out.println("Error Limit");
        }
    }
}
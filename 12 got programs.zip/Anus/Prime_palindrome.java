import java.util.*;
public class Prime_palindrome
{
    int m,n;
    void input()
    {
        Scanner sc = new Scanner (System.in);
        System.out.print("Enter the value of m : ");
        m=sc.nextInt();
        System.out.print("Enter the value of n : ");
        n=sc.nextInt();
    }

    boolean check_palindrome(int x)
    {
        int r=0,copy,d;
        copy=x;
        while(x>0)
        {
            d=x%10;
            x=x/10;
            r=r*10+d;
        }
        if(r==copy)
            return true;
        else
            return false;
    }

    boolean check_prime(int y)
    {
        int c=0,i;
        for(i=1;i<=y/2;i++)
        {
            if(y%i==0)
                c++;
        }
        if(c==1)
            return true;
        else
            return false;
    }

    void show()
    {
        Prime_palindrome obj = new Prime_palindrome();
        int k;
        boolean pr,pa;
        System.out.println("Prime palindrome numbers between "+m+" and "+n+" are ");
        for(k=m;k<=n;k++)
        {
            pa=obj.check_palindrome(k);
            pr=obj.check_prime(k);
            if(pa==true&&pr==true)
                System.out.println(k);
        }
    }

    public static void main()
    {
        Prime_palindrome obj = new Prime_palindrome();
        obj.input();
        obj.show();
    }
}
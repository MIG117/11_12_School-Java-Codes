import java.util.*;
public class InvertNameNumberPattern
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,b,k;
        String a;
        System.out.println("Enter the Name to print Name and Number Pattern");
        a=sc.nextLine();
        b=a.length();
        for(i=b;i>=1;i--)
        {
            System.out.println(a.substring(0,i));
        }
        for(j=b;j>=1;j--)
        {
            for(k=1;k<=j;k++)
            {
                System.out.print(k);
            }
            System.out.println();
        }
    }
}
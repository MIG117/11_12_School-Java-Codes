import java.util.*;
public class Pattern7
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,n;
        System.out.println("Enter the Limit to print '#' in your pattern");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print("#");
            }
            System.out.println();
        }
    }
}
import java.util.*;
public class Pascals_Triangle
{
    int r,i,k,n=1,j;
    void input()
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter the Number of Rows");
        r=sc.nextInt();
    }
    
    void print()
    {
        for(i=0;i<r;i++)
        {
            for(k=r;k>i;k--)
            {
                System.out.print(" ");
            }
            n=1;
            for(j=0;j<=i;j++)
            {
                System.out.print(n+" ");
                n=n*(i-j)/(j+1);
            }
            System.out.println();
        }
    }
    
    public static void main()
    {
        Pascals_Triangle obj = new Pascals_Triangle();
        obj.input();
        obj.print();
    }
}
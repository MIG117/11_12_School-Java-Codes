import java.util.*;
class IscScores
{
    static Scanner sc = new Scanner(System.in);
    int number[][];
    
    IscScores()
    {
        number=new int[6][2];
    }
    
    void inputMarks()
    {
        System.out.println("First Enter the marks & Enter the Subject code : ");
        for(int i=0;i<2;i++)
        {
            for(int j=0;j<6;j++)
            {
                number[j][i] = sc.nextInt();
            }
        }
    }
    
    int point(int x)
    {
        if(x>=90&&x<=100)
            return 1;
        else if(x>=80&&x<90)
            return 2;
        else if(x>=70&&x<80)
            return 3;
        else if(x>=60&&x<70)
            return 4;
        else if(x>=50&&x<60)
            return 5;
        else if(x>=40&&x<50)
            return 6;
        else if(x>=30&&x<40)
            return 7;
        else if(x>=20&&x<30)
            return 8;
        else if(x>=10&&x<20)
            return 9;
        else
            return 10;
    }
}
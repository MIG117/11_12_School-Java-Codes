import java.util.*;
class eleminate
{
    static Scanner sc = new Scanner(System.in);
    int arr[] = new int [10],i,j;
    void input()
    {
        System.out.println("Enter 10 number");
        for(i=0;i<10;i++)
        {
            arr[i]=sc.nextInt();
        }
    }

    void eleminate()
    {
        for(i=0;i<10-1;i++)
        {
            for(j=i+1;j<10;j++)
            {
                if(arr[i]==arr[j])
                    arr[j] =-999999999;
            }
        }
    }

    void show()
    {
        System.out.println("Array after eleminating duplicate values");
        for(i=0;i<10;i++)
        {
            if(arr[i]!=-999999999)
                System.out.println(arr[i]);
        }
    }

    public static void main()
    {
        eleminate obj = new eleminate();
        obj.input();
        obj.eleminate();
        obj.show();
    }
}
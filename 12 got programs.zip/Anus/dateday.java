import java.util.*;
class dateday
{
    static Scanner sc = new Scanner(System.in);
    int i,n;
    int month[]={0,31,28,31,30,31,30,31,31,30,31,30,31};

    int isleap(int y)
    {
        if((y%400==0)||(y%100!=0)&&(y%4==0))
            return 29;
        else
            return 28;
    }

    boolean datevalidation(int d,int m,int y)
    {
        month[2]=isleap(y);
        if(m<1||m>12||d<1||d>month[m]||y<1000||y>9999)
            return false;
        return true;
    }

    int dayno(int d,int m,int y)
    {
        int dn=0;
        month[2]=isleap(y);
        for(i=1;i<m;i++)
        {
            dn=dn+month[i];
        }
        dn=dn+d;
        for(i=1000;i<y;i++)
        {
            if(isleap(i)==29)
                dn=dn+366;
            else
                dn=dn+365;
        }
        return dn;
    }

    public static void main()
    {
        int x,y,i;
        String dw[]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Firday","Saturday"};

        dateday ob=new dateday();

        System.out.println("Enter the day of 1st January : ");
        String str = sc.nextLine();

        int p,q;
        System.out.print("Enter present date in dd/mm/yyyy format : ");
        String date2=sc.nextLine().trim();
        p=date2.indexOf("/");
        int d1=Integer.parseInt(date2.substring(0,p));
        q=date2.lastIndexOf("/");
        int m1=Integer.parseInt(date2.substring(p+1,q));
        int y1=Integer.parseInt(date2.substring(q+1));

        if(ob.datevalidation(d1,m1,y1))
        {
            x=ob.dayno(01,01,y1);
            y=ob.dayno(d1,m1,y1);
            int z=Math.abs(x-y);
            for(i=0;i<7;i++)
            {
                if(dw[i].equalsIgnoreCase(str))
                    break;
            }
            z=z+i;
            z=z%7;
            System.out.println("Day of the Preffered date is : "+dw[z]);
        }
    }
}
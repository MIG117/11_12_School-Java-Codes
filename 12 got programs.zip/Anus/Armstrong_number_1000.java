class Armstrong_number_1000
{
    void armstrong_1000()
    {
        int i,k,s=0,copy,d;
        System.out.println("Armstrong Numbers between 1 - 1000 are :");
        for(i=1;i<=1000;i++)
        {
            s=0;
            copy=i;
            while(copy>0)
            {
                d=copy % 10;
                copy = copy / 10;
                s=s+(d+d+d);
            }
            if(s==i)
            System.out.println(i);
        }
    }
    
    public static void main()
    {
        Armstrong_number_1000 obj = new Armstrong_number_1000();
        obj.armstrong_1000();
    }
}
import java.util.*;
public class terenary
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Enter the Number");
        n=sc.nextInt();
        System.out.println((n>0)?"Positive":(n<0)?"Negative":"Zero");
    }
}
import java.util.*;
class functionbike
{
        String name;
        int age,bikeno,phno,price,date1,date2,day,days;
        
        void input()
        {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the name of Bike Owner");
        name = sc.nextLine();
        System.out.println("Enter the Bike Number");
        bikeno = sc.nextInt();
        System.out.println("Enter the Age of th Bike Owner");
        age = sc.nextInt();
        System.out.println("Enter the Phone Number of the Bike Owner");
        phno = sc.nextInt();
        System.out.println("Enter the Price of the Bike");
        price = sc.nextInt();
        System.out.println("Enter the Dates  after purchasing the bike to till date");
        date1 = sc.nextInt();
        date2 = sc.nextInt();
    }
    
    void compute()
    {
        if(date1<=31&&date2<=31)
        day = date2-date2;
        days = day*24;
        
    }
    void display()
    {
        System.out.println("Name\tAge\tPhone No.\tBike No.\tPrice\tTime after purchase");
        System.out.println(name+"\t"+age+"\t"+phno+"\t"+bikeno+"\t"+price+"\t"+days);
    }
    
    public static void main()
    {
        functionbike ob = new functionbike();
        ob.input();
        ob.compute();
        ob.display();
    }
}

    
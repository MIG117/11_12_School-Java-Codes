import java.util.*;
class diagnol_sum
{
    int n,m,i,j,sr=0,sl=0,s=0,arr[][];
    static Scanner sc = new Scanner(System.in);
    
    diagnol_sum(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr = new int [n][m];
    }
    
    void input()
    {
        System.out.println("Enter the Elements of the Matrix : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    
    void Sum_diagnol()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(i==j)
                {
                    sl=sl+arr[i][j];
                }
                if(i+j==m-1)
                {
                    sr=sr+arr[i][j];
                }
                s=sl-sr;
            }
        }
        System.out.println("The Difference of the sum of the Diagnols are : " +s);
    }
    
    public static void main()
    {
        System.out.println("Enter the Dimensions of the matrix : ");
        int n1=sc.nextInt();
        int m1=sc.nextInt();
        diagnol_sum obj = new diagnol_sum(n1,m1);
        obj.input();
        obj.Sum_diagnol();
    }
}
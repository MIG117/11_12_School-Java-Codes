import java.util.*;
import java.io.*;

class pin_cracked
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your data to get cracked : ");
        String str = sc.nextLine();
        if(str.length()==4)
        {
            try
            {
                File f = new File("file.txt");
                Scanner read = new Scanner(f);
                while(read.hasNextLine())
                {
                    String data = read.nextLine();
                    if(data.equals(str))
                    {
                        System.out.println("Your pin is = "+data);
                        break;
                    }
                }
                read.close();
            }

            catch(IOException e)
            {
                System.out.println("Error Occured...");
                e.printStackTrace();
            }
        }
        else
        {
            System.out.println("Limit out of reach!!!");
        }
    }
}
import java.util.*;
class hex
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        
        String octnum, hexnum, bin;
        int decnum;
        
        System.out.print("Enter a octal number : ");
        octnum = sc.nextLine();
        
        decnum = Integer.parseInt(octnum, 8);
        bin = Integer.toBinaryString(decnum);
        hexnum = Integer.toHexString(decnum).toUpperCase();
        
        System.out.println("HEXADECIMAL NUMBER : "+hexnum);
    }
}
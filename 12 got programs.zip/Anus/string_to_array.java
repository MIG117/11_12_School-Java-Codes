import java.util.*;

class string_to_array
{
    static Scanner sc = new Scanner (System.in);
    int len,k=0;
    String str,temp="";
    String arr[]=new String[100];

    void input()
    {
        System.out.print("Enter a string : ");
        str=sc.nextLine();
        str=str+" ";
        //System.out.println(str);
    }

    void Conversion()
    {
        len=str.length();
        for(int i=0;i<len;i++)
        {
            if(str.charAt(i)!=' ')
            {
                temp=temp+str.charAt(i);
            }
            else
            {
                arr[k++]=temp;
                temp="";
            }
        }
    }

    void display()
    {
        System.out.println("The Arrayed String :  ");
        for(int i=0;i<k;i++)
        {
            System.out.println(arr[i]);
        }
    }

    public static void main()
    {
        string_to_array ob = new string_to_array();
        ob.input();
        ob.Conversion();
        ob.display();
    }
}
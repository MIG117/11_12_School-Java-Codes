import java.util.*;
public class sirpattren3
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,k,n;
        System.out.println("Enter the Limit");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(j=i;j<n;j++)
            {
                System.out.print("  ");
            }
            k=i;
            for(j=1;j<2*i;j++)
            {
                System.out.print(k+" ");
                if(j<i)
                k--;
                else
                k++;
            }
            System.out.println();
        }
    }
}
import java.util.*;
class overload
{
    void compare(int n,int a)
    {
        if(n>a)
        System.out.println("The greatest number : "+n);
        else
        System.out.println("The greatest number : "+a);
    }
    void compare(char ch1,char ch2)
    {
        int n,a;
        n=(int)ch1;
        a=(int)ch2;
        if(n>a)
        System.out.println("The greatest Character : "+ch1);
        else
        System.out.println("The greatest Character : "+ch2);
    }
    void compare(String st1,String st2)
    {
        int n,a;
        n=st1.length();
        a=st2.length();
        if(n>a)
        System.out.println("The longer String : "+st1);
        else
        System.out.println("The longer String : "+st2);
    }
    void main()
    {
        Scanner sc = new Scanner(System.in);
        int ch,a,b;
        char ch1,ch2;
        String st1,st2;
        System.out.println("##Menu##");
        System.out.println("1.Compare 2 integer values : ");
        System.out.println("2.Compare numeric value of 2 Character : ");
        System.out.println("3.Compare lenght of 2 strings : ");
        System.out.println("Enter Your Choice : ");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
            System.out.println("Enter two integers : ");
            a=sc.nextInt();
            b=sc.nextInt();
            compare(a,b);
            break;
            case 2:
            System.out.println("Enter two Characters : ");
            ch1=sc.next().charAt(0);
            ch2=sc.next().charAt(0);
            compare(ch1,ch2);
            break;
            case 3:
            System.out.println("Enter two Strings : ");
            st1=sc.nextLine();
            st2=sc.nextLine();
            compare(st1,st2);
            break;
            default:
            System.out.println("Wrong Choice");
        }
    }
    public static void call ()
    {
        overload obj=new overload();
        obj.main();
    }
}
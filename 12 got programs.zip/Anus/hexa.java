import java.util.*;
class hexa
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,r,i=0,j=0;
        String  d=" ";
        System.out.println("Enter any Nummber");
        n=sc.nextInt();
         while(n>0)
        {
            r=n%10;
            i=i+r*(int)Math.pow(8,j);
            n=n/10;
            j++;
        }
        r=0;
        while(i>0)
        {
            r=i%16;
            d=Integer.toString(r)+d;
            i=i/16;
        }
        System.out.println("The Binary Equivalent ="+d);
    }
}

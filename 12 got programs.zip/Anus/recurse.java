;import java.util.*;
class recurse
{
    static Scanner sc = new Scanner(System.in);
    int i,j,rev =0,n,m,f=2;

    void input()
    {
        System.out.println("Number : ");
        n=sc.nextInt();
    }

    int isprime(int y)
    {
        if(f!=y)
        {
            while(f<y)
            {
                if(y%f!=0)
                {
                    f++;
                    isprime(y/2);
                }
                else
                    return 0;
            }
        } 
        return 1;
    }

    void check()
    {
        int cpy=n;
        if(isprime(cpy)==0)
            while(n>0)
            {
                int d=n%10;
                n=n/10;
                rev=rev*10+d;
            }
        if(isprime(rev)==0)
        {
            System.out.println("Emirp");
        }
        else
            System.out.println("Not Emirp");
    }

    public static void main()
    {
        recurse k = new recurse();
        k.input();
        k.check();
    }
}
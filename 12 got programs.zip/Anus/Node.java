/*wap to */

import java.util.*;
class Node
{
    int d;
    Node link;
} 
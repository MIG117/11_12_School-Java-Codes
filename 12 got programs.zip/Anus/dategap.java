import java.util.*;
class dategap
{
    static Scanner sc= new Scanner(System.in);
    int date,i,j,k,n;
    int month[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    
    int isleap(int y)
    {
        if((y%400==0)||(y%100!=0)&&(y%4==0))
            return 29;
        else
            return 28;
    }
    
    boolean datevalidation(int d,int m,int y)
    {
        month[2]=isleap(y);
        if(m<1||m>12||d<1||d>month[m]||y<1000||y>9999)
            return false;
        return true;
    }
    
    int dayno(int d,int m,int y)
    {
        int dn=0;
        month[2]=isleap(y);
        for(i=1;i<m;i++)
        {
            dn=dn+month[i];
        }
        dn=dn+d;
        for(i=1000;i<y;i++)
        {
            if(isleap(i)==29)
                dn=dn+366;
            else
                dn=dn+365;
            }
        return dn;
        }
        
    public static void main()
    {
        dategap ob=new dategap();
        System.out.print("Enter 1st date in dd/mm/yyyy format : ");
        String date1=sc.nextLine().trim();
        int p,q;
        p=date1.indexOf("/");
        int d1=Integer.parseInt(date1.substring(0,p));
        q=date1.lastIndexOf("/");
        int m1=Integer.parseInt(date1.substring(p+1,q));
        int y1=Integer.parseInt(date1.substring(q+1));
        p=q=0;
        
        System.out.print("Enter 2nd date in dd/mm/yyyy format : ");
        String date2=sc.nextLine().trim();
        p=date1.indexOf("/");
        int d2=Integer.parseInt(date2.substring(0,p));
        q=date1.lastIndexOf("/");
        int m2=Integer.parseInt(date2.substring(p+1,q));
        int y2=Integer.parseInt(date2.substring(q+1));
        int x,y;
        if(ob.datevalidation(d1,m1,y1)&&ob.datevalidation(d2,m2,y2))
        {
            x=ob.dayno(d1,m1,y1);
            y=ob.dayno(d2,m2,y2);
            // System.out.println(x);
            // System.out.println(y);
            System.out.println("Difference between dates : "+(y-x));
        }
        else
        {
            System.out.println("INVALID DATE...");
        }
    }
    }
class test
{
    public static void main()
    {
        int arr[]={5,8,2,9};
        int arr2[]={9,8,5,2};
        int[] don=anas.arrayascend1d(arr);
        int[] kon=anas.arraydecend1d(arr2);
        for(int i=0;i<don.length;i++)
        {
            System.out.print(don[i]+" ");
        }
        System.out.println();
        for(int i=0;i<kon.length;i++)
        {
            System.out.print(kon[i]+" ");
        }
        int a=anas.count(456);
        int r=anas.reverse(125);
        // System.out.println(r);
    }
}
import java.util.*;
public class Loop
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,n;
        System.out.println("Enter the Limit");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(i);
            }
            System.out.println();
        }
    }
}
            
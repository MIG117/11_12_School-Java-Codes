import java.util.*;
public class functionstudents
{
    String name;
    int stand,age,m1,m2,m3;
    double avg;
    
    void input()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Name of the Student :");
        name = sc.nextLine();
        System.out.println("Enter the Age of the student :");
        age = sc.nextInt();
        System.out.println("Enter the Class of the student :");
        stand = sc.nextInt();
        System.out.println("Enter the marks of subject 1 :");
        m1 = sc.nextInt();
        System.out.println("Enter the marks of subject 2 :");
        m2 = sc.nextInt();
        System.out.println("Enter the marks of subject 3 :");
        m3 = sc.nextInt();
    }
    
    void compute()
    {
        avg = m1+m2+m3/3;
        System.out.println("The Average marks of the Student"+avg);
    }
    
    void display()
    {
        System.out.println("Name\tAge\tClass\tMarks1\tMarks2\tMarks3\tAverage Marks");
        System.out.println(name+"\t"+age+"\t"+stand+"\t"+m1+"\t"+m2+"\t"+m3+"\t"+avg);
    }
    
    public static void main()
    {
    functionstudents ob = new functionstudents();
    ob.input();
    ob.compute();
    ob.display();
}
}
    
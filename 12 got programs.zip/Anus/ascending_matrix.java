import java.util.*;
class ascending_matrix
{
    int n,m,i,j,k,arr[][],t=0;
    static Scanner sc = new Scanner (System.in);
    
    ascending_matrix(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr=new int [n][m];
    }
    
    void input()
    {
        System.out.println("Enter the Elements of the matrix : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    
    void Sort()
    {
        System.out.println("Original Matrix");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.println(arr[i][j]+"  ");
                }
            }
        for(i=0;i<n;i++)
        {
            for(j=0;j<m-1;j++)
            {
                for(k=0;k<m-j-1;k++)
                {
                    if(arr[i][k]>arr[i][k+1])
                    {
                        t=arr[i][k];
                        arr[i][k]=arr[i][k+1];
                        arr[i][k+1]=t;
                    }
                }
            }
            System.out.println();
        }
    }
    
    void print()
    {
        System.out.println("Sorted Matrix");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j]+"  ");
            }
            System.out.println();
        }
    }
    
    public static void main()
    {
        System.out.println("Enter the Dimensions of the matrix : NOTE that the Values of n & m should be Equal : ");
        int n1=sc.nextInt();
        int m1=sc.nextInt();
        if(n1!=m1)
        System.out.println("Values are not Same");
        else
        {
            if(n1>3&&n1<15)
            {
                ascending_matrix obj = new ascending_matrix(n1,m1);
                obj.input();
                obj.Sort();
                obj.print();
            }
            else
            {
                System.out.println("INVALID SIZE OF RANGE");
            }
        }
    }
}
import java.util.*;
class twoDtoOneD
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int arr[][],ar[],i,j,n,m,k=0,c=0,o=0;
        System.out.println("Enter the Dimensions of 2D-MATRIX : ");
        n=sc.nextInt();
        m=sc.nextInt();
        arr=new int[n][m];
        System.out.println("Input of the MATRIX : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j]=sc.nextInt();
            }
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }
        ar=new int[n*m];
        System.out.println("The 2D MATRIX converted into 1D ARRAY is : ");
        for(i=0;i<n;i++)
        {
            while(c<m)
            {
                ar[k]=arr[i][o];
                if(o!=m)
                {
                    o++;
                }
                if(k!=n*m)
                {
                    k++;
                }
                c++;
            }
            o=0;
            c=0;
        }
        for(i=0;i<n*m;i++)
        {
            System.out.println(ar[i]);
        }
    }
}
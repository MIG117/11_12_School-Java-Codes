import java.util.*;

class transpose
{
    static Scanner sc = new Scanner(System.in);
    int arr[][],arr1[][],i,j,n,m;

    transpose(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr = new int[n][m];
        arr1 = new int[m][n];
    }

    void input()
    {
        System.out.println("Enter the Elements of the Matrix : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    
    void transpose()
    {
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                arr[i][j] = arr[j][i];
            }
        }
    }
    
    void display()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
        
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    public static void main()
    {
        System.out.println("Enter the Dimension");
        int n1 = sc.nextInt();
        int m1 = sc.nextInt();
        transpose done = new transpose(n1,m1);
        done.input();
        done.transpose();
        done.display();
    }
}
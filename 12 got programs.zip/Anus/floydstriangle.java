import java.util.*;
class floydstriangle
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,a,n,num=1;
        System.out.println("#*# MENU #*#");
        System.out.println("1.Floyd's Triangle");
        System.out.println("2.ICSE Triangle");
        System.out.println("Enter your Choice");
        a=sc.nextInt();
        switch(a)
        {
            case 1:
            System.out.println("Enter the Limit");
            n=sc.nextInt();
            for(i=1;i<=n;i++)
            {
                for(j=1;j<=i;j++)
                {
                    System.out.print(num+" ");
                    num++;
                }
                System.out.println();
            }
            break;
            case 2:
            System.out.println("ICSE");
            String str="ICSE";
            n=str.length();
            for(i=0;i<n;i++)
            {
                for(j=0;j<=i;j++)
                {
                    System.out.print(" ");
                    System.out.print(str.charAt(j));
                }
                System.out.println();
            }
            break;
            default:
            System.out.println("WRONG CHOICE");
            break;
        }
        System.out.println("Again Enter your Choice please");
        a=sc.nextInt();
        switch(a)
        {
            case 1:
            System.out.println("Enter the Limit");
            n=sc.nextInt();
            for(i=1;i<=n;i++)
            {
                for(j=1;j<=i;j++)
                {
                    System.out.print(2*j-1);
                }
                System.out.println();
            }
            break;
            case 2:
            System.out.println("ICSE");
            String str="ICSE";
            n=str.length();
            for(i=0;i<n;i++)
            {
                for(j=0;j<=i;j++)
                {
                    System.out.print(" ");
                    System.out.print(str.charAt(j));
                }
                System.out.println();
            }
            break;
            default:
            System.out.println("WRONG CHOICE");
            break;
        }
    }
}

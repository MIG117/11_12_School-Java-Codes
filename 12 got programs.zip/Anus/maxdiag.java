import java.util.*;
class maxdiag
{
    int arr[][],i,j,m,n;
    static Scanner sc= new Scanner(System.in);
    maxdiag(int nn, int mm)
    {
        n=nn;
        m=mm;
        arr=new int[n][m];
    }

    void input()
    {
        System.out.println("Enter the elements : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }

    void diag()
    {
        int max = arr[0][0],temp=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(arr[i][j]>max)
                {
                    max = arr[i][j];
                }
            }
        }
        System.out.println("Output : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(i==j||i+j==m-1)
                    System.out.print(max+" ");
                else
                    System.out.print(" ");
            }
            System.out.println();
        }
    }

    public static void main()
    {
        System.out.print("Enter the dimensions of the matrix : ");
        int n1 = sc.nextInt();
        int m1 = sc.nextInt();
        maxdiag md = new maxdiag(n1,m1);
        md.input();
        md.diag();
    }
}
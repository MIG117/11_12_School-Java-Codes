import java.util.*;

class possible {
    static Scanner sc = new Scanner(System.in);
    String str;
    char ch[];
    int n, i, j, s = 0, l;

    void Permutations(String st) {
        n = st.length();
        ch = new char[n];
        char[] ch2 = new char[n];
        ch = st.toCharArray();
        ch2 = st.toCharArray();
        for (l = 0; l < n * n; l++) {
            for (i = 0; i < n; i++) {
                char c = ch2[0];
                ch2[0] = ch2[i];
                ch2[i] = c;
                for (j = 1; j < n - 1; j++) {
                    ch[0] = ch2[0];
                    char k = ch[j];
                    ch[j] = ch[j + 1];
                    ch[j + 1] = k;
                    String str2 = new String(ch);
                    System.out.println(str2);
                }
            }
        }
    }

    public static void main(String args[]) {
        System.out.println("Enter a String to get Possible Combinations : ");
        String st1 = sc.next();
        int v2 = 0;
        if (v2 == st1.length()) {
            System.out.println(st1);
        }
        possible obj = new possible();
        obj.Permutations(st1);
    }
}
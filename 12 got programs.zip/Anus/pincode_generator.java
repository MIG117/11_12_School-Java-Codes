import java.util.*;
import java.io.*;
class pincode_generator {
    static Scanner sc = new Scanner(System.in);
    int i, j, n, k, l,c=0;
    String str = "", str1 = "", str2 = "";
    String stra[] = new String[10000];
    // void generate() {
    // File file = new File("F://test.txt");
    // if(file.createNewFile())
    // System.out.println("Created");
    // else
    // System.out.println("Unsuccessful");
    // for (i = 0; i < 10; i++) {
    // for (j = 0; j < 10; j++) {
    // for (k = 0; k < 10; k++) {
    // for (l = 0; l < 10; l++) {
    // str = str + Integer.toString(i) + Integer.toString(j) + Integer.toString(k)
    // + Integer.toString(l);

    // FileWriter writer = new FileWriter(file);

    // str = "";
    // }
    // }
    // }
    // }
    // }
    void display()
    {
        System.out.println("The Codes are : ");
        for(i=0;i<c;i++)
        {
            System.out.println(stra[i]);
        }
    }

    public static void main(String[] args) throws IOException
    {
        // pincode_generator pin = new pincode_generator();
        // pin.generate();
        // pin.display();
        int i, j, n, k, l,c=0;
        String str = "", str1 = "", str2 = "";
        String stra[] = new String[10000];
        File file = new File("F://test.txt");
        if(file.createNewFile())
            System.out.println("Created");
        else
            System.out.println("Unsuccessful");
        for (i = 0; i < 10; i++) {
            for (j = 0; j < 10; j++) {
                for (k = 0; k < 10; k++) {
                    for (l = 0; l < 10; l++) {
                        str = Integer.toString(i) + Integer.toString(j) + Integer.toString(k)
                        + Integer.toString(l);
                        stra[c++]=str;
                        FileWriter writer = new FileWriter(file);
                        writer.write(str);
                        writer.close();
                        str="";
                    }
                }
            }
        }
    }
}
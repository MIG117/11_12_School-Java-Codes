import java.util.*;
public class ElectricBill
{
    String n;
    int units;
    double bill=0,surcharge=0;
    void accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Name of the Customer");
        n=sc.nextLine();
        System.out.println("Enter the Units consumed by the Customer");
        units=sc.nextInt();
    }
    void calculate()
    {
        if(units<=100)
        bill=units*2.00;
        else if(units>100&units<=200)
        bill=units*3.00;
        else if(units>300)
        bill=units*5.00;
        surcharge=bill*2.5/100;
        bill=bill+surcharge;
    }
    void print()
    {
        System.out.println("Name of the Customer : "+n);
        System.out.println("Number of Units Consumed : "+units);
        System.out.println("Bill Amount : "+bill);
    }
    
    public static void main()
    {
        ElectricBill obj = new ElectricBill();
        obj.accept();
        obj.calculate();
        obj.print();
    }
}
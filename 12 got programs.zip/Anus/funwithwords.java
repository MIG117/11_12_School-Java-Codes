import java.util.*;
public class funwithwords
{
    public static void main()
    {
        Scanner sc = new Scanner (System.in);
        int i,n,n2,n3,n4;
        String str,str1,cutstr,cutstr1;
        System.out.println("You can only Exchange words with the use of index numbers of the words it starts with 0 in this case");
        System.out.println();
        System.out.println("Plzz Enter your First Word");
        str=sc.next();
        System.out.println("plzz Enter your Second Word");
        str1=sc.next();
        System.out.print("Plzz Enter your first index After which your cropping starts : ");n=sc.nextInt();System.out.println("Plzz Enter your second index where your cropping Ends : ");n2=sc.nextInt();
        cutstr=str.substring(n,n2);
        System.out.print("Plzz Enter your first index After which your cropping starts : ");n3=sc.nextInt();System.out.println("Plzz Enter your second index where your cropping Ends : ");n4=sc.nextInt();
        cutstr1=str1.substring(n3,n4);
        System.out.println("Your Fun Word is : "+(cutstr+cutstr1));
    }
}
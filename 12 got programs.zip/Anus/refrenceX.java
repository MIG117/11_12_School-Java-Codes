import java.util.*;
class refrenceX
{
    int a, b;
    static Scanner sc= new Scanner(System.in);

    void input()
    {
        System.out.println("Enter the value of A & B : ");
        a=sc.nextInt();
        b=sc.nextInt();
    }

    void display()
    {
        System.out.println("Value of A = "+a);
        System.out.println("Value of B = "+b);
    }
    
    public static void main()
    {
        refrenceX x = new refrenceX();
        x.input();
        x.display();
    }
}
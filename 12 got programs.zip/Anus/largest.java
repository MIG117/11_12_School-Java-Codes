import java.util.*;
public class largest
{
    int n,a,b,maxi,x;

    void input()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Three Numbers");
        n=sc.nextInt();
        a=sc.nextInt();
        b=sc.nextInt();
    }

    void compute()
    {
        x = Math.max(n,a);
        maxi = Math.max(x,b);
    }

    void display()
    {
        System.out.println("The Largaest Number : "+maxi);
    }

    public static void main()
    {
        largest ob = new largest();
        ob.input();
        ob.compute();
        ob.display();
    }
} 
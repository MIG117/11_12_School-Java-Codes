import java.util.*;
class exchange
{
    static Scanner sc = new Scanner(System.in);
    int arr[][],i,j,n,m;
    
    exchange(int nn, int mm)
    {
        n=nn;
        m=mm;
        arr=new int[n][m];
    }
    
    void input()
    {
        System.out.println("Enter the elements : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    
    void exchnge()
    {
        int temp=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                temp=arr[0][j];
                arr[0][j]=arr[n-1][j];
                arr[n-1][j]=temp;
            }
            
            for(j=0;j<m;j++)
            {
                temp=arr[j][0];
                arr[j][0]=arr[j][m-1];
                arr[j][m-1]=temp;
            }
        }
    }
    
    void display()
    {
        System.out.println("output : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    
    public static void main()
    {
        System.out.println("Enter the dimensions : ");
        int n1=sc.nextInt();
        int m1=sc.nextInt();
        exchange ex = new exchange(n1,m1);
        ex.input();
        ex.exchnge();
        ex.display();
    }
}
import java.util.*;
public class Pattern2
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,k,n;
        System.out.println("Enter the Limit");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(k=i;k<n;k++)
            {
                System.out.print(" ");
            }
            for(j=1;j<=i;j++)
            {
                System.out.print(j);
            }
            System.out.println();
        }
    }
}
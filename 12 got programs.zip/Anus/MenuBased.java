import java.util.*;
public class MenuBased
{
    Scanner sc = new Scanner(System.in);
    double area;
    void MenuBased()
    {
        area=0.0;
    }
    int menu()
    {
        int ch;
        System.out.println("^^MENU^^");
        System.out.println("1.Square");
        System.out.println("2.Rectangle");
        System.out.println("3.Circle");
        System.out.println("4.Exit");
        System.out.println("Enter your Choice :");
        ch=sc.nextInt();
        return ch;
    }

    void showArea()
    {
        double s,l,b,r;
        switch(menu())
        {
            case 1:
            System.out.println("Enter the Side of the Square :");
            s=sc.nextDouble();
            area=s*s;
            System.out.println("The Area of the Square is :"+area);
            break;
            case 2:
            System.out.println("Enter the Lenght and Breath of the Rectangle :");
            l=sc.nextDouble();
            b=sc.nextDouble();
            area=l*b;
            System.out.println("The Area of the Rectangle is :"+area);
            break;
            case 3:
            System.out.println("Enter the Radius of the Circle :");
            r=sc.nextDouble();
            area=3.14*r*r;
            System.out.println("The Area of the Circle :"+area);
            break;
            case 4:
            System.out.println(0);
            break;
            default:
            System.out.println("WRONG CHOICE");
        }
    }

    public static void main()
    {
        MenuBased ob = new MenuBased();
        ob.MenuBased();
        ob.showArea();
    }
}
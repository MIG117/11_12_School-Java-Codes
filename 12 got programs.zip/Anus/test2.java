import java.util.*;
class test2
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int arr[][],i,j;
        System.out.println("Enter dimensions : ");
        i = sc.nextInt();
        arr = new int[i][i];
        System.out.println("Enter : ");
        for(int n=0;n<i;n++)
        {
            for(j=0;j<i;j++)
            {
                arr[n][j] = sc.nextInt();
            }
        }
        arr = anas.arrdecend2dc(arr);
        
        for(int n=0;n<i;n++)
        {
            for(j=0;j<i;j++)
            {
                System.out.print(arr[n][j]+" ");
            }
            System.out.println();
        }
    }
}
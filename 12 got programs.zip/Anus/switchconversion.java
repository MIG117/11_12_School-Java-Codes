import java.util.*;

class switchconversion
{
    static Scanner sc =  new Scanner(System.in);
    int i=0,j,r;
    String d;
    char ch=' ';
    
    switchconversion()
    {
        j=0;
        d=" ";
    }
    
    void decimal_to_binary(int n)
    {
        while(n>0)
        {
            r=n%2;
            d=Integer.toString(r)+d;
            n=n/2;
        }
        System.out.println("Binary Equivalent : " +d);
    }
    
    void octal_to_hexadecimal(int n)
    {
         while(n>0)
        {
            r=n%10;
            i=i+r*(int)Math.pow(8,j);
            n=n/10;
            j++;
            
        }
        r=0;
        while(i>0)
        {
            r=i%16;
            if(i==10||r==10)
                ch='A';
            if(i==11||r==11)
                ch='B';
            if(i==12||r==12)
                ch='C';
            if(i==13||r==13)
                ch='D';
            if(i==14||r==14)
                ch='E';
            if(i==15||r==15)
                ch='F';
            /*if(i<16||r<16)
                d=Integer.toString(r)+ch;
                i=i/16;*/
            d=Integer.toString(r)+d;
            i=i/16;  
        }
        System.out.println("HexaDecimal Equivalent : "+d);
    }
    
    public static void main()
    {
        int i,n1,ch;
        System.out.println("These are ur Options : ");
        System.out.println("1.Decimal to Binary");
        System.out.println("2.Octal to HexaDecimal");
        System.out.print("Enter ur choice : ");
        ch=sc.nextInt();
        switchconversion switched = new switchconversion();
        switch(ch)
        {
            case 1:
            System.out.print("Enter ur number : ");
            n1=sc.nextInt();
            switched.decimal_to_binary(n1);
            break;
            
            case 2:
            System.out.print("Enter ur number : ");
            n1=sc.nextInt();
            switched.octal_to_hexadecimal(n1);
        }
    }
}
// wap to design a class area with the following functions
// void square (int s)
// void rectangle (int l,int b)
// void triangle (intb,int h)
import java.util.*;
public class area
{
    Scanner sc = new Scanner(System.in);
    int area;
    void square(int s)
    {
        area = s*s;
        System.out.println("The Area of Square : "+area);

    }

    void rectangle(int l,int b)
    {
        area = l*b;
        System.out.println("The Area of Rectangle : " +area);
    }

    void triangle(int b,int h)
    {
        area = 1/2*b*h;
        System.out.println("The Area of Triangle : "+area);
    }
    void main()
    {
        Scanner sc =  new Scanner(System.in);
        int s,l,b,h,ch;
        System.out.println("##Menu##");
        System.out.println("1.To Find the Arae of Square ");
        System.out.println("2.To Find the Area of Rectangle : ");
        System.out.println("3.To Find the Area of Triangle : ");
        System.out.println("Enter Your Choice : ");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
            System.out.println("Enter the Side of a Square :");
            s = sc.nextInt();
            square(s);
            break;
            case 2:
            System.out.println("Enter the Lenght & Breath of a Rectangle :");
            l=sc.nextInt();
            b=sc.nextInt();
            rectangle(l,b);
            break;
            case 3:
            System.out.println("Enter the Base & Height of a Triangle :");
            b=sc.nextInt();
            h=sc.nextInt();
            triangle(b,h);
            break;
            default:
            System.out.println("Wrong Choice");
        }
    }
    public static void call()
    {
        area obj = new area();
        obj.main();
    }
}
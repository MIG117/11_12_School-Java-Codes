import java.util.*;

class permutations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a String to get All Possible Combinations : ");
        String n = sc.next();
        permute(0, n);
    }

    static void permute(int fixed, String str) {
        char[] chr = str.toCharArray();
        if (fixed == str.length()) {
            System.out.println(str);
        }
        for (int i = fixed; i < str.length(); i++) {
            char c = chr[i];
            chr[i] = chr[fixed];
            chr[fixed] = c;
            permute(fixed + 1, new String(chr));
        }
    }
}

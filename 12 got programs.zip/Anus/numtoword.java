import java.util.*;
class numtoword
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,i,j,len;
        String ones[] = {"zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
        String tens[] = {"","Ten","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninty"};
        String hundreds[] = {"hundred","thousdand",};
        String str="";

        System.out.println("Enter the Integer : ");
        n=sc.nextInt();
        len = anas.count(n);
        while(n>0)
        {
            len = anas.count(n);
            if(len==1)
            {
                str=str + " " +ones[n] + " ";
                n=n-n;
            }
            else if(len==2)
            {
                i=n/10;
                str=str + " " + tens[i] + " ";
                n=n%10;
            }
            else if(len==3)
            {
                i=n/100;
                str=str + " " + ones[i] + " " + hundreds[0] + " and ";
                n=n%100;
            }
            else if(len==4)
            {
                i=n/1000;
                str=str + " " + ones[i] + " " + hundreds[1] + " ";
                n=n%1000;
            }
        }
        if(str=="")
            System.out.println("zero");
        else
            System.out.println(str);
        String a = "anasa";
        System.out.println(a.substring(0,4));
    }
}
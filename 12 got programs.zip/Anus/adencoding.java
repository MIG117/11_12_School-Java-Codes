import java.util.*;
class adencoding
{
    public static void main()
    {
        String str,str1="",co;
        int i,s,len,d,c;
        char ch,ch1;
        Scanner sc = new Scanner(System.in);
        System.out.println("Don't Forget To add 0 in front of any Once digit number!!!");
        System.out.print("Enter string to decode : ");
        str=sc.nextLine();
        len=str.length();
        co=str.substring(len-2,len);
        s=Integer.parseInt(co);
        if(s>0&&s<27)
        {
            for(i=0;i<len;i++)
            {
                ch=str.charAt(i);
                if((ch>='A'&&ch<='Z'))
                {
                    d=ch+(s-1);
                    if((char)d=='Q'&&i<len-1)
                    {
                        ch1=str.charAt(i+1);
                        c=ch1+(s-1);
                        if((char)c=='Q')
                            d=32;
                        i++;
                    }
                    if(d>90)
                        d=d-26;
                    ch=(char)d;
                    str1=str1+ch;
                }
            }
            System.out.print(str1);
        }
        else
        {
            System.out.println("Invalid Decoding Number Added at last!!!");
        }
    }
}
import java.util.*;
class Bestfour extends IscScores
{
    static Scanner sc = new Scanner(System.in);
    int temp;
    void bestSubjects()
    {
        inputMarks();
        for(int i=0;i<6;i++)
        {
            for(int j=0;j<6-1-i;j++)
            {
                if(point(number[j][0])>point(number[j+1][0]))
                {
                    temp=number[j][0];
                    number[j][0]=number[j+1][0];
                    number[j+1][0]=temp;

                     temp=number[j][1];
                     number[j][1]=number[j+1][1];
                     number[j+1][1]=temp;
                }
            }
        }
        System.out.println("Subjects");
        for(int i=0;i<4;i++)
        {
            for(int j=0;j<2;j++)
            {
                System.out.print(number[i][j]+" ");
            }
            System.out.println();
        }
    }
}
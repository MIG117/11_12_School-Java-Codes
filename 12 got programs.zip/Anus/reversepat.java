import java.util.*;
class reversepat
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,n;
        System.out.print("Enter a limit : ");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(j=i;j>=1;j--)
            {
                System.out.print(j);
            }
            System.out.println();
        }
    }
}
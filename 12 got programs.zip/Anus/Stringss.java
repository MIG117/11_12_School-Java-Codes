import java.util.*;
class Stringss
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        String a,b;
        int n,i,up=0,lw=0,sp=0, d=0, spc=0;
        char ch;
        System.out.println("Enter The String :");
        a=sc.nextLine();
        n=a.length();
        for(i=0;i<n;i++)
        {
            ch=a.charAt(i);
            if(ch>='a'&&ch<='z')
            {
                up=up+1;
            }
            else if(ch>='A'&&ch<='Z')
            {
                lw=lw+1;
            }
            else if(ch>='0'&&ch<='9')
            {
                d=d+1;
            }
            else
            {
                spc=spc+1;
            }
        }
        System.out.println("Lower case :"+up);
        System.out.println("Upper Case :"+lw);
        System.out.println("Special Character :"+spc);
        System.out.println("Digits :"+d);
    }
}

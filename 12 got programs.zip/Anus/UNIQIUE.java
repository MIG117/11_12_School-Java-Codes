//pg_24
import java.util.*;
class UNIQIUE
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,d,n,a=0,n2,c,f=0;
        System.out.println("Enter the Number");
        n=sc.nextInt();
        for(i=0;i<=9;i++)
        {
            n2=n;
            c=0;
            while(n>0)
            {
                d=n2%10;
                n2=n2/10;
                if(i==d)
                {
                    c++;
                }
            }
            if(c>1)
            {
                f=0;
                break;
            }
        }
        if(f==1)
            System.out.println("The Number is UNIQUE");
        else
            System.out.println("The Number is not UNIQUE");
    }
}
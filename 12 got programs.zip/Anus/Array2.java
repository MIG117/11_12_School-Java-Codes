import java.util.*;
public class Array2
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,min,n;
        System.out.println("Enter the size of the array: ");
        n=sc.nextInt();
        int a[]=new int [n];
        System.out.println("Enter the values of the array");
        for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        min=0;
        for(i=1;i<n;i++)
        {
            if(a[min]>a[i])
            min=i;
        }
        System.out.println("Minimum Value is : "+a[min]);
    }
}
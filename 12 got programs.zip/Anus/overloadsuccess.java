






import java.util.*;
class overloadsuccess
{

    void check(String st,char ch)
    {
        int d,c=0,i;
        char a;
        d=st.length();
        for(i=0;i<d;i++)
        {
            a=st.charAt(i);
            if(a==ch)
            {
                c++;
                System.out.println("The Frequency of Entered Chrarcter is :"+c);
            }
            else
            {
                System.out.println("There are no Such Characters");
            }
        }
    }

    void check(String str)
    {
        int n,i;
        String a;
        char d;
        a=str.toLowerCase();
        n=a.length();
        for(i=0;i<=n;i++)
        {
            d=str.charAt(i);
            if (d=='a'||d=='e'||d=='i'||d=='o'||d=='u')
            {
                System.out.println("The Vowels in String "+str+"are :"+d);
            }
            else
            { 
                System.out.println("There are No Vowels in String "+str);
            }
        }
    }

    void main()
    {
        Scanner sc = new Scanner(System.in);
        int n;
        String st;
        String str;
        char ch;
        System.out.println("^^MENU^^");
        System.out.println("1.Check the Frequency of Character of String enter by you");
        System.out.println("2.Check the Number of Vowels Present in the String entered by you");
        System.out.println("Enter Your Choice");
        n=sc.nextInt();
        switch(n)
        {
            case 1:
            System.out.println("Enter a String :");
            st=sc.nextLine();
            System.out.println("Enter a Character to check its Frequency :");
            ch=sc.next().charAt(0);
            check(st,ch);
            break;
            case 2:
            System.out.println("Enter a String");
            str=sc.nextLine();
            check(str);
            break;
            default:
            System.out.println("WRONG CHOICE");
        }
    }

    public static void call ()
    {
        overloadsuccess ob = new overloadsuccess();
        ob.main();
    }
}

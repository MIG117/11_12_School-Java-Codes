import java.util.*;

class Roman
{
    static Scanner sc = new Scanner(System.in);
    int n,i,j;
    String str = "";
    String RomanNum[] = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
    int Decimals[] = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
    
    void roman(int num)
    {
        for(i=0;i<13;i++)
        {
            while(num>=Decimals[i])
            {
                num = num-Decimals[i];
                str=str+RomanNum[i];
            }
        }
        System.out.print("CONVERTED!!! : "+str);
    }
    
    public static void main()
    {
        System.out.print("Enter a Number : ");
        int n=sc.nextInt();
        Roman numbers = new Roman();
        numbers.roman(n);
    }
}
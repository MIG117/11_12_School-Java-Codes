import java.util.*;
class boundary
{
    int i,j,n,m,arr[][];
    static Scanner sc = new Scanner(System.in);
    
    boundary(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr = new int[n][m];
    }
    
    void input()
    {
        System.out.println("Enter the Elements of the Matrix : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    
    void boundary_print()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(i==0||j==0||i==n-1||j==m-1)
                {
                    System.out.print(arr[i][j] + "  ");
                }
                else
                {
                    System.out.print("   ");
                }
            }
            System.out.println();
        }
    }
    
    public static void main()
    {
        System.out.println("Enter the Dimensions of the Matrix : ");
        int n1=sc.nextInt();
        int m1=sc.nextInt();
        boundary obj = new boundary(n1,m1);
        obj.input();
        obj.boundary_print();
    }
}
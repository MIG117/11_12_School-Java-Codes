import java.util.*;
class StrchngVowel
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        String a;
        int n,i,c=0;
        char ch;
        System.out.println("Enter The String");
        a=sc.nextLine();
        n=a.length();
        for(i=0;i<n;i++)
        {
            ch=a.charAt(i);
            if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
                c=c+1;
        }
        System.out.println("No of vowels :"+c);
    }
}
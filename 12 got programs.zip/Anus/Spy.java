import java.util.*;
public class Spy
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,i,d,s=0,p=1;
        System.out.println("Enter the Number you want to Check whether its a spy no. or not");
        n=sc.nextInt();
        while(n>0)
        {
            d=n%10;
            n=n/10;
            s=s+d;
            p=p*d;
        }
        if(p==s)
            System.out.println("The Number is a Spy Number");
        else
            System.out.println("The Number is Not a Spy Number");
    }
}
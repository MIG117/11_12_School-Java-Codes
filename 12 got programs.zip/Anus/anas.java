class anas
{
    public static int count(int n)
    {
        int c=0,d;
        while(n>0)
        {
            d=n%10;
            n=n/10;
            c++;
        }
        return c;
    }

    public static int reverse(int n)
    {
        int r=0,d;
        while(n>0)
        {
            d=n%10;
            n=n/10;
            r=r*10+d;
        }
        return r;
    }

    public static int[] arrayascend1d(int arr[])
    {
        int i,j,temp=0,n=arr.length;
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                if(arr[i]<arr[j])
                {
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
                temp=0;
            }
        }
        return arr;
    }

    public static int[] arraydecend1d(int arr[])
    {
        int i,j,temp=0,n=arr.length;
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                if(arr[i]>arr[j])
                {
                    temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
                temp=0;
            }
        }
        return arr;
    }

    public static int[][] arrascend2dr(int arr[][])
    {
        int i,j,temp=0,n=arr.length;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n-1;j++)
            {
                for(int k=j+1;k<n;k++)
                {
                    if(arr[i][j]>arr[i][k])
                    {
                        temp=arr[i][j];
                        arr[i][j]=arr[i][k];
                        arr[i][k]=temp;
                    }
                    temp=0;
                }
            }
        }
        return arr;
    }

    public static int[][] arrdecend2dr(int arr[][])
    {
        int i,j,temp=0,n=arr.length;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n-1;j++)
            {
                for(int k=j+1;k<n;k++)
                {
                    if(arr[i][j]<arr[i][k])
                    {
                        temp=arr[i][k];
                        arr[i][k]=arr[i][j];
                        arr[i][j]=temp;
                    }
                    temp=0;
                }
            }
        }
        return arr;
    }

    public static int[][] arrascend2dc(int arr[][])
    {
        int i,j,temp=0,n=arr.length;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n-1;j++)
            {
                for(int k=j+1;k<n;k++)
                {
                    if(arr[j][i]>arr[k][i])
                    {
                        temp=arr[j][i];
                        arr[j][i]=arr[k][i];
                        arr[k][i]=temp;
                    }
                    temp=0;
                }
            }
        }
        return arr;
    }

    public static int[][] arrdecend2dc(int arr[][])
    {
        int i,j,temp=0,n=arr.length;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n-1;j++)
            {
                for(int k=j+1;k<n;k++)
                {
                    if(arr[j][i]<arr[k][i])
                    {
                        temp=arr[k][i];
                        arr[k][i]=arr[j][i];
                        arr[j][i]=temp;
                    }
                    temp=0;
                }
            }
        }
        return arr;
    }

    public static int[] dateformat(String n)
    {
        int arr[] = new int[3];
        int p,q;
        n = n.trim();
        p=n.indexOf("/");
        int d=Integer.parseInt(n.substring(0,p));
        q=n.lastIndexOf("/");
        int m=Integer.parseInt(n.substring(p+1,q));
        int y=Integer.parseInt(n.substring(q+1));

        arr[0]=d;
        arr[1]=m;
        arr[2]=y;
        
        return arr;
    }

    public static int isleap(int y)
    {
        if((y%400==0)||(y%100!=0)&&(y%4==0))
            return 29;
        else
            return 28;
    }
    
    public static boolean validate(int d, int m, int y)
    {
        int month[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
        month[2]=isleap(y);
        if(m<1||m>12||d<1||d>month[m]||y<1000||y>9999)
            return false;
        return true;
    }
}
import java.util.*;
class krishnamurthynumber
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,d,sum=0,n2,fact,n;
        System.out.print("Enter a Number : ");
        n=sc.nextInt();
        n2=n;
        while(n!=0)
        {
            d=n%10;
            n=n/10;
            fact=1;
            for(i=1;i<=d;i++)
            {
                fact*=i;
            }
            sum+=fact;
        }
        if(sum==n2)
        System.out.println("The Number is Krishnamurthy Number.");
        else
        System.out.println("The Number is Not a krishnamurthy Number.");
    }
}
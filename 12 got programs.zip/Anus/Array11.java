import java.util.*;
class Array11
{
    static Scanner sc = new Scanner(System.in);
    int arr[][],i,j,n,m,k,lb,rb;
    Array11(int n1,int n2)
    {
        n=n1;
        m = n2;
        arr = new int[n][m];
        k=0;
    }

    void Input()
    {
        System.out.println("Enter the  Elements of The Array");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }
    
    void Print_Diagnol()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(i==j||i+j==m-1)
                
                    System.out.print(arr[i][j]+" ");
                
                else
                
                    System.out.print("  ");
                
            }
            System.out.println();
            
        }
    }
    
    public static void main()
    {
        System.out.println("Enter the Size of the Array");
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        Array11 a1 = new Array11(n1,n2);
        a1.Input();
        a1.Print_Diagnol();
    }
}

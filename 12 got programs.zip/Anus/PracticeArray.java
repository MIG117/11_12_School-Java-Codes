import java .util.*;
public class PracticeArray
{
    public static void main()
    {
        Scanner sc = new Scanner (System.in);;
        int n,i,p=-1,s;
        System.out.println("Enter the number of Array:");
        n=sc.nextInt();
        int a[]=new int[n];
        for(i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
        System.out.println("Enter the Number to be  Search:");
        s=sc.nextInt();
        for(i=0;i<n;i++)
        {
            if(a[i] == s)
            p=i+1;
        }
        if(p>-1)
        System.out.println("The Element is present in Array:"+p);
        else
        System.out.println("The Element is not present");
    }
}
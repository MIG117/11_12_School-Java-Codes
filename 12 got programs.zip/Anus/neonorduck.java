import java.util.*;
public class neonorduck
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,ch,d;
        System.out.println("Enter Your Choice");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
            int s=0,sq;
            System.out.println("Enter the Number to Check the Neon Number");
            n=sc.nextInt();
            sq=n*n;
            while(sq>0)
            {
               sq=sq/10;
                d=sq%10;
                s=s+n;
            }
            if(n==s)
            System.out.println("The Number is a Neon Number");
            else
            System.out.println("The Number is not a Neon Number");
            break;
            case 2:
            System.out.println("Enter the Number to Check the Duck Number");
            n=sc.nextInt();
            while(n>0)
            {
                n=n/10;
                d=n%10;
                if(d==0)
                System.out.println("The Number is a Duck Number");
                else
                System.out.println("The Number is not a Duck Number");
            }
            break;
            default:
            System.out.println("WRONG CHOICE");
        }
    }
}
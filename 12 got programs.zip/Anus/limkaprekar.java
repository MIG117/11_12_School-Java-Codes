import java.util.*;
class limkaprekar
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,m,a,c=0,i,sq,x,y,n2;
        System.out.println("Enter the Limit Numbers");
        n=sc.nextInt();//45;
        m=sc.nextInt();
        System.out.println("The Numbers listed below are kaprekar : ");
        while(n!=m)
        {
            int cp=n;
            int cpy=n;
            sq = (int)Math.pow(cpy,2);
            while(cp>0)
            {
                cp=cp/10;
                c++;
                x = sq%(int)Math.pow(10,c);
                y = sq/(int)Math.pow(10,c);
                if((x+y)==n)
                {
                    System.out.println(n);
                }
                x=y=c=0;
                n++;
            }
        }
    }
}
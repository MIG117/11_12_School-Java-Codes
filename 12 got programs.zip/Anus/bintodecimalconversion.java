import java.util.*;
class bintodecimalconversion
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,c=0;
        double r,d=0;
        System.out.println("Enter binary code");
        n=sc.nextInt();
        while(n>0)
        {
            r=n%10;
            d=d+r*Math.pow(2,c);
            n=n/10;
            c=c+1;
        }
        System.out.println("The Decimal Equivalent ="+(int)d);
    }
}

import java.util.*;
public class Reverse
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,d,r=0;
        System.out.println("Enter the Number");
        n=sc.nextInt();
        while(n>0)
        {
            d=n%10;
            n=n/10;
            r=r*10+d;
        }
        System.out.println("The Reversed Number = "+r);
    }
}
import java.util.*;

class diagnolSwap
{
    static Scanner sc = new Scanner(System.in);
    int i,j,m,n,max=0,min=0,c=(m-1)/2,arr[][],a=0,b=0;

    diagnolSwap(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr = new int[n][m];
    }

    void input()
    {
        System.out.println("Enter the Elements of the Matrix : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }

    void diagnol()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j]  + " ");
            }
            System.out.println();
        }

        max = arr[0][0];
        min = arr[0][0];

        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
    
                if(max<arr[i][j])
                {
                    max=arr[i][j];
                }
    
                if(min>arr[i][j])
                {
                    min=arr[i][j];
                }
    
            }
        }

        int d=m;
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {

                if(i==j)
                {
                    if(d%2==1&&a==b)
                    {
                        c=(d-1)/2;
                        //System.out.print(c);
                        arr[c][c]=min;
                        System.out.print(arr[c][c]);
                        b++;
                    }
                    else
                        System.out.print(min);
                }

                if(i+j==m-1&&i*i+j!=c*c+c||i==0&&j==m-1)
                {
                    System.out.print(max);
                }

                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

    public static void main()
    {
        System.out.println("Enter the Dimensions : ");
        int n1 = sc.nextInt();
        int m1 = sc.nextInt();
        diagnolSwap d1 = new diagnolSwap(n1,m1);
        d1.input();
        d1.diagnol();
    }
}


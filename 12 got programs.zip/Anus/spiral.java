import java.util.*;
class spiral
{
    static Scanner sc=new Scanner(System.in);
    int n,arr[][],i,j,m;
    spiral()
    {
        arr=new int[4][4];
    }

    void clockwise()
    {
        int k=1,z=1,x=0,y=-1;
        int i,j,r=3,c=4;
        while(k<=16)
        {
            for(i=0;i<c;i++)
            {
                y=y+z;
                arr[x][y] = k;
                k++;
            }
            for(i=0;i<r;i++)
            {
                x=x+z;
                arr[x][y]=k;
                k++;
            }
            r--;
            c--;
            z=-z;
        }
    }
    
    void display()
    {
        System.out.println("MATRIX");
        for(i=0;i<4;i++)
        {
            for(j=0;j<4;j++)
            {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        /*int n1,m1;
        System.out.println("Enter The Integer:");
        n1=sc.nextInt();
        m1=sc.nextInt();
        s1.input();*/
        
        spiral s1=new spiral();
        s1.clockwise();
        s1.display();
    }
}
import java.util.*;
class diagnol_matrices 
{
    static Scanner sc = new Scanner (System.in);
    int arr[][],i,j,n,m;
    diagnol_matrices(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr = new int[n][m];
    }
    
    void input()
    {
        System.out.println("Enter the elements of the Matrix");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j]=sc.nextInt();
            }
        }
    }
    
    void print_diagnol()
    {
        System.out.println("Diagnol of the Matrix");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                if(i==j||i+j==m-1)
                System.out.print(arr[i][j]+"\t");
                else
                System.out.print("\t");
            }
            System.out.println();
            System.out.println();
        }
    }

    public static void main ()
    {
       System.out.println("Enter the Rows & Columns");
       int n1=sc.nextInt();
       int m1=sc.nextInt();
       diagnol_matrices obj = new diagnol_matrices(n1,m1);
       obj.input();
       obj.print_diagnol();
    }
}
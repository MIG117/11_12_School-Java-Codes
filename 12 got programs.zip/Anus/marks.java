import java.util.*;
class marks
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int m,e1,e2,h,g,p,c,b,hin,beng,arts,fm,sum;
        double per;
        System.out.println("If some of the subjects are not included in your syllabus...plzz Enter 0 ");
        System.out.println();
        System.out.print("Enter your Maths marks : ");
        m=sc.nextInt();
        System.out.print("Enter your Language marks : ");
        e1=sc.nextInt();
        System.out.print("Enter your Literature marks : ");
        e2=sc.nextInt();
        System.out.print("Enter your History marks : ");
        h=sc.nextInt();
        System.out.print("Enter your Geography marks : ");
        g=sc.nextInt();
        System.out.print("Enter your Physics marks : ");
        p=sc.nextInt();
        System.out.print("Enter your Chemistry marks : ");
        c=sc.nextInt();
        System.out.print("Enter your Biology marks : ");
        b=sc.nextInt();
        System.out.print("Enter your Hindi marks : ");
        hin=sc.nextInt();
        System.out.print("Enter your Bengali marks : ");
        beng=sc.nextInt();
        System.out.print("Enter your Arts marks : ");
        arts=sc.nextInt();
        System.out.print("Enter your Full marks of your all subjects marks : ");
        fm=sc.nextInt();
        sum=(m+e1+e2+h+g+p+c+b+hin+beng+arts);
        per=(sum*100)/fm;
        System.out.println("Your Percentage is : "+per+"%");
    }
}
import java.util.*;
class Kaprekar
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,a,c=0, sq,x,y,n2;
        System.out.println("Enter the Number");
        n=sc.nextInt();//45;
        sq = n*n;//2025;
        while(n>0)
        {
            n=n/10;//45/10=4.5,which is countable;
            c++;//c+1=1;c+1=2:because this c++ loop will run twice because of two digits;
        }
        x = sq%(int)Math.pow(10,c);//2025%10*10=25;
        y = sq/(int)Math.pow(10,c);//2025/10*10=20.25=20;
        if(x+y==n)//20+25=45;
            System.out.println("The Number is Kaprekar");
        else
            System.out.println("The Number is not Kaprekar");
    }
}
import java.util.*;
class hashstarpattern
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int a,i,j,n;
        System.out.println("Enter the limit");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=i;j++)
            {
                if(j%2==0)
                {
                    System.out.print("#");
                }
                else
                {
                    System.out.print("*");
                }
            }
            System.out.println();
        }
    }
}
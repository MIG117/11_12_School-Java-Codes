import java.util.*;

class palindromearray {
    static Scanner sc = new Scanner(System.in);
    int arr[], n, c = 0, i, j;

    palindromearray(int nn) {
        n = nn;
        arr = new int[n];
    }

    void input() {
        System.out.println("Enter the elements : ");
        for (i = 0; i < n; i++) {
            arr[i] = sc.nextInt();

        }
    }

    void reverse() {
        int r = 0, d, cpy;
        for (i = 0; i < n; i++) {
            j = arr[i];
            cpy = j;
            while (j > 0) {
                d = j % 10;
                j = j / 10;
                r = r * 10 + d;
            }
            if (cpy == r) {
                c++;
            }
            arr[i] = r;
            r = 0;
        }
    }

    void display() {
        System.out.println("The Elemnts Reversed : ");
        for (i = 0; i < n; i++) {
            System.out.println(arr[i]);
        }
        System.out.println("The Number of Palindrome Numbers are : " + c);
    }

    public static void main(String args[]) {
        System.out.println("Enter the limit of String : ");
        int n1 = sc.nextInt();
        palindromearray obj = new palindromearray(n1);
        obj.input();
        obj.reverse();
        obj.display();
    }
}
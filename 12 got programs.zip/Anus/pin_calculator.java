import java.util.*;
import java.io.*;

class pin_calculator
{
    static Scanner sc = new Scanner(System.in);
    int i,j,k,l;
    String str = "";

    String pin()
    {
        for(i=0;i<10;i++)
        {
            for(j=0;j<10;j++)
            {
                for(k=0;k<10;k++)
                {
                    for(l=0;l<10;l++)
                    {
                        str = str + i + j + k + l + "\n";
                    }
                }
            }
        }
        return str;
    }

    public static void main()
    {
        pin_calculator p = new pin_calculator();
        String st = p.pin();
        File fr=new File("file.txt");
        try
        {
            if(fr.createNewFile())
            {
                System.out.println("File created");
            }
            else
            {
                System.out.println("File already exist");
            }
        }
        catch(IOException e)
        {
            System.out.println("An error occured");
        }

        try
        {
            FileWriter f = new FileWriter("file.txt");
            f.write(st);
            f.close();
        }
        catch (IOException e)
        {
            System.out.println("An error occured");
        }
    }
}
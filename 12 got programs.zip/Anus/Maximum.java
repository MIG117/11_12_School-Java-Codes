import java.util.*;
public class Maximum
{
        String name;
        int age,m1,m2,m3,max;
        double avg;
        void accept()
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the Name");
            name=sc.nextLine();
            System.out.println("Enter the age");
            age=sc.nextInt();
            System.out.println("Enter The marks in subject 1");
            m1=sc.nextInt();
            System.out.println("Enter the marks in subject 2");
            m2=sc.nextInt();
            System.out.println("Enter the marks in subject 3");
            m3=sc.nextInt();
        }
        
        void compute()
        {
            avg=(m1+m2+m3)/3.0;
            max=m1;
            if(max<m2)
            max=m2;
            if(max<m3)
            max=m3;
        }
        
        void display()
        {
            System.out.println("Name :"+name);
            System.out.println("Age :"+age);
            System.out.println("Subject 1 :"+m1);
            System.out.println("Subject 2 :"+m2);
            System.out.println("Subject 3:"+m3);
            System.out.println("Maximum Marks :"+max);
            System.out.println("Average marks :"+avg);
        }
        
        public static void main()
        {
            Maximum s1 = new Maximum();
            s1.accept();
            s1.compute();
            s1.display();
        }
    }


import java.util.*;
public class numbers
{
    int n,d,n1=0;
    Scanner sc = new Scanner(System.in);
    void accept()
    {
        System.out.println("Enter a Number");
        n=sc.nextInt();
        n1=n;
    }
    
    void prime()
    {
        n1=n1/10;
        d=n1%10;
        if(n1==3||n1==5||n1==7||n1==2)
        System.out.println("The Entered Number is a Prime Number");
        else
        System.out.println("The Entered  Number is not a Prime Number");
    }
    
    void print()
    {
        System.out.println("The original Number : "+n);
        System.out.println("The Squared Program : "+(n*n));
    }
    
    public static void main()
    {
        numbers ob = new numbers();
        ob.accept();
        ob.prime();
        ob.print();
    }
}
import java.util.*;
class volume
{
    void volume(int a)
    {
    double v;
    v=6*a*a;
    System.out.println("Volume of cube:"+v);
}
void volume(int a,int b, int c)
{
    double v;
    v=a*b*c;
    System.out.println("Volume of cuboid:"+v);
}
void volume(int r,int h)
{
    double v;
    v=3.14*r*r*h;
    System.out.println("Volume of right circular solid cylinder : "+v);
}
void volume(int h,float r)
{
    double v;
    v=1/3*Math.PI*r*r*h;
    System.out.println("Volume of right circular cone : "+v);
}
void volume(float r)
{
    double v;
    v=4/3*3.14*r*r*r;
    System.out.println("Volume of the sphere : "+v);
}
void main()
{
    Scanner sc =new Scanner (System.in);
    int ch,r,h,l,b,a;
    float r1;
    System.out.println("Menu");
    System.out.println("1.Volume of cube");
    System.out.println("2.Volume of cuboid");
    System.out.println("3.Volume of right circular solid cylinder");
    System.out.println("4.Volume of right circular cone");
    System.out.println("5.Volume of Sphere");
    System.out.println("Enter Your choice");
    ch=sc.nextInt();
    switch(ch)
    {
        case 1:
        System.out.println("Enter the side of Cube");
        a=sc.nextInt();
        volume(a);
        break;
        case 2:
        System.out.println("Enter the length,breath and height of Cuboid");
        l=sc.nextInt();
        b=sc.nextInt();
        h=sc.nextInt();
        volume(l,b,h);
        break;
        case 3:
        System.out.println("Enter the radius and height of a Cylinder");
        r=sc.nextInt();
        h=sc.nextInt();
        volume(r,h);
        break;
        case 4:
        System.out.println("Enter the height and radius");
        h=sc.nextInt();
        r1=sc.nextFloat();
        volume(h,r1);
        break;
        case 5:
        System.out.println("Enter the radius of a Sphere");
        r1=sc.nextFloat();
        volume(r1);
        break;
        default:
        System.out.println("Wrong Choice");
    }
}
public static void call()
{
    volume obj=new volume();
    obj.main();
}
}
import java.util.*;
class Niven
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,n,d,s=0;
        System.out.println("Enter a Number");
        n=sc.nextInt();
        while(n>0)
        {
            n=n/10;
            d=n%10;
            s=s+d;
        }
        if(n%s==0)
        {
            System.out.println("The Number is Niven");
        }
        else
        {
            System.out.println("The Number is Not Niven");
        }
    }
}

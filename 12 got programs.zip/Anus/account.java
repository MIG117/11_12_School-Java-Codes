/*wap a program to input a class account with the following features
Data members
name 
age
account
acct type
bal
member methods
void input
void display
void deposit
void withdraw*/
import java.util.*;
class account
{
    Scanner sc = new Scanner(System.in);
    String name,accttype;
    int age,acct;
    double bal,n,i,deposit,withdraw;
    void input ()
    {
        System.out.println("Enter the Name");
        name = sc.nextLine();
        System.out.println("Enter the Age");
        age = sc.nextInt();
        System.out.println("Enter the Account Number");
        acct = sc.nextInt();
        System.out.println("Enter the Account Type (Reccuring or Savings)");
        accttype = sc.nextLine();
        System.out.println("Balance");
        bal = sc.nextDouble();
    }

    void display()
    {
        System.out.println("Name\tAge\tAccount Number\tAccount Type\tBalance");
        System.out.println(name+"\t"+age+"\t"+acct+"\t"+accttype+"\t"+bal);
    }

    void deposit ()
    {
        System.out.println("Enter the ammount to be deposited");
        n=sc.nextDouble();
        deposit=bal+n;
        System.out.println("New Balance : "+deposit);
    }

    void withdraw()
    {
        System.out.println("Enter the Ammount you want to withdraw");
        i = sc.nextDouble();
        if(i>=bal)
            System.out.println("The Withdraw is not possible");
        else
            withdraw=deposit-i;
        System.out.println("New Balance : "+withdraw);
    }

    public static void main()
    {
        account obj = new account();
        obj.input();
        obj.display();
        obj.deposit();
        obj.withdraw();
    }
}
import java.util.*;
class clock
{
    static Scanner sc= new Scanner (System.in);
    int i,j,k;
    String n,str="",p1,p2;
    String hours[] = {"","one","two","three","four","five","six","seven","eight","nine","ten","eleven","tweleve"};
    String tens[] = {"","Ten","Twenty","Thirty","Forty","Fifty"};
    String semitens[] = {"","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};
    void input()
    {
        System.out.println("Enter the time : ");
        n=sc.next();
    }

    void calculate()
    {
        int g = n.indexOf(":");
        p1 = n.substring(0,g);
        p2 = n.substring(g+1);
        int len1 = p1.length();
        int len2 = p2.length();
        int a = Integer.parseInt(p1);
        int b = Integer.parseInt(p2);

        if(a>12||a<0||b>59||b<0)
            System.out.println("Invalid Time Format");
        if(len1==1||len1==2)
            str = str + hours[a];
        if(b==00)
        {
            str = str + " o'clock";
            System.out.println(str);
        }
        else if(b<31)
            past(b,str);
        else
        {
            if(a==12)
                str="one";
            to(b,str);
        }

    }

    void past(int b, String str)
    {
        int len2 = anas.count(b);
        if(len2==1)
            str = str + hours[b];

        if(len2==2)
        {
            if(b==30)
            {
                str = "Half past " + str;
            }
            else if(b==15)
            {
                str = "Quater past " + str;
            }
            else
            {
                i=b/10;
                j=b%10;
                str = tens[i] + hours[j] + " minutes past " + str;
            }
        }
        // str = tens[b] + "minutes past" + str;
        System.out.println(str);
    }

    void to(int b, String str)
    {
        int len2 = anas.count(b);
        if(len2==1)
            str = str + hours[b];
        if(len2==2)
        {
            if(b==45)
            {
                str = "Quater to " + str;
            }
            else
            {
                int m=60-b;
                String s = Integer.toString(m);
                if(m<20&&m>10)
                {

                    str = semitens[m-10] + " minutes to " + str;
                }
                if(m>19&&m<59)
                {
                    i=m/10;
                    j=m%10;
                    str = tens[i] + hours[j] + " minutes to " + str;
                }
                if(m<10&&m>0)
                {
                    str = hours[m] + " minutes to " + str;
                }
            }

        }
        System.out.println(str);
    }

    public static void main()
    {
        clock c= new clock();
        c.input();
        c.calculate();
    }
}
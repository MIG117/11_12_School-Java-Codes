import java.util.*;
class yrmonday
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int yr,yr2,mon,day,d,i;
        System.out.print("Enter the Number of days :");
        d = sc.nextInt();
        yr = d/365;
        yr2 = d%365;
        mon = yr2/30;
        day = yr2%30;
        System.out.println("The no. of years :"+yr);
        System.out.println("The no. of months :"+mon);
        System.out.println("The no. of days :"+day);
    }
}

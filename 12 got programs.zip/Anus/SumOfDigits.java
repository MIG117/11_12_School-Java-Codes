import java .util.*;
public class SumOfDigits
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,d,s=0;
        System.out.println("Enter The Number");
        n=sc.nextInt();
        while(n>0)//suppose if we take 426,then
        {
            d=n%10;//% will save the remainder  on dividing 426 i.e.6 after first loop
            n=n/10;// / will save Quotient on dividing 426 i.e.42 after fuirst loop
            s=s+d;//it will save value //the loop will keep on executing and saving values
        }
        System.out.println("The sum of series = "+s);
    }
} 
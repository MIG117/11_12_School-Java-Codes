import java.util.*;
public class NamePattern
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
        int i,n,j;
        String a;
        System.out.println("Enter the name to convert it into pattern");
        a=sc.nextLine();
        n=a.length();
        for(i=0;i<=n;i++)
        {
                System.out.println(a.substring(0,i));
        }
    }
}
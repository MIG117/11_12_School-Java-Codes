
import java.util.*;
class Array3
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,a[],i;
        System.out.println("Enter the Limit of Array");
        n=sc.nextInt();
        a=new int[n];
        System.out.println("Enter the Elements");
        for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        System.out.println("The Even Elements in the Array are : ");
        for(i=0;i<n;i++)
        {
            if(a[i]%2==0)
            System.out.println(a[i]);
        }
    }
}
import java.util.*;
class numdecode
{
    public static void main()
    {
        String st,str="",str1="",sht="";
        char ch,ch1;
        int i,n,j,k,l,d,r=0,len;
        //Long n;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter");
        st=sc.nextLine();
        len=st.length();
        while(st!="")
        {
            if(len>8)
            {
                //l=st.getlastIndexOf(32);
                System.out.println(sht=st.substring(len-8,len));
                len-=8;
            }
            else
            {
                System.out.print(sht=st.substring(0,len));
                len-=len;
            }
            if(st!="")
            {
            n=Integer.parseInt(sht);
            while(n>0)
            {
                d=n%10;
                n=n/10;
                str=str+Integer.toString(d);
                if(str.length()==2)
                {
                    k=Integer.parseInt(str);
                    ch=(char)k;
                    if((ch>='A'||ch>='a')||(ch==32))
                    {
                        str1=str1+ch;
                        str="";
                    }
                    else
                    {
                        d=n%10;
                        //System.out.print("Inside");
                        n=n/10;
                        str=str+Integer.toString(d);
                    }
                }
                if(str.length()==3)
                {
                    k=Integer.parseInt(str);
                    ch=(char)k;
                    if((ch>='A'||ch<='Z')||(ch>='a'||ch<='z')||(ch==32))
                    {
                        str1=str1+ch;
                        str="";
                    }
                }
            }
        }
        }
        System.out.print(str1);
    }
}
import java.util.*;
public class Function
{
    String name;
    int bno,phno,days,charge;
    void input()
    {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the Name :");
    name = sc.nextLine();
    System.out.println("Enter the Bike Number :");
    bno = sc.nextInt();
    System.out.println("Enter the Phone number :");
    phno = sc.nextInt();
    System.out.println("Enter the number of Days Rented :");
    days = sc.nextInt();
}

void compute()
{
    if(days<=5)
    charge = days*500;
    else if(days<=10)
    charge = 2500+(days-5)*400;
    else
    charge = 4500+(days-10)*200;
}

void display()
{
    System.out.println("Bike No.\tPhone No.\tName\tNo. of Days\tCharge");
    System.out.println(bno+"\t"+phno+"\t"+name+"\t"+days+"\t"+charge);
}

public static void main()
{
    Function ob = new Function();
    ob.input();
    ob.compute();
    ob.display();
}
}

import java.util.*;
public class Pattern9
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,n;
        System.out.println("Enter the Limit to print'#' in your invert pattern");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(j=i;j<=n;j++)
            {
                System.out.print("#");
            }
            System.out.println();
        }
    }
}
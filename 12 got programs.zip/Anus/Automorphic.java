import java.util.*;
class Automorphic
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,a,c=0, sq, x, n2;
        System.out.println("Enter the Number");
        n=sc.nextInt();
        sq = n*n;
        n2 = n;
        while(n>0)
        {
            n=n/10;
            c=c+1;
        }
        x = sq%(int)Math.pow(10, c);
        if(n2==x)
            System.out.println("The Number is Automorphic");
        else
            System.out.println("The Number is not Automorphic");
    }
}
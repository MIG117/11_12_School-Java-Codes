import java.util.*;
class priime
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,i,d;
        System.out.println("Enter the Number");
        n=sc.nextInt();
        while(n>0)
        {
            d=n%10;
            n=n/10;
            if(d==2||d==3||d==5||d==7)
            System.out.println(d);
        }
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
import java.util.*;
class factors
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,n,d=0,s;
        System.out.println("Enter the number");
        n=sc.nextInt();
        for(i=1;i<n;i++)
        {
            if(n%i==0)
            {
                System.out.print(i+",");
            }
        }
    }
}
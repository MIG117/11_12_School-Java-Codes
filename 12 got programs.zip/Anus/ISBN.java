import java.util.*;
class ISBN
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        long s=0,n,d,x;
        System.out.println("Enter a 10-Digit ISBN number");
        n=sc.nextLong();
        if(!(n>99999999 && n<=999999999))
        {
            System.out.println("Illegal ISBN");
        }
        else
        {
            x=10;
            while(n>0)
            {
                d=n%10;
                n=n/10;
                s=s+x*d;
                x--;
            }
            if(x%11==0)
            {
                System.out.println("The Entered Number is Legal ISBN number");
            }
            else
            {
                System.out.println("The Entered Number is an Illegal ISBN number");
            }
        }
    }
}
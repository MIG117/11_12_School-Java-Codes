class call
{
    public static void main()
    {
        Bestfour bs = new Bestfour();
        bs.bestSubjects();
    }
}
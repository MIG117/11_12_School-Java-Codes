import java.util.*;
public class Pattern3
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,k,n;
        System.out.println("Enter the Limit");
        n=sc.nextInt();
        for(i=n;i>=1;i--)
        {
            for(k=1;k<i;k++)
            {
            System.out.print(" ");
        }
            for(j=n;j>=i;j--)
            {
            System.out.print(j);
        }
            System.out.println();
        }
    }
}
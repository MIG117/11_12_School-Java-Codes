import java.util.*;

class outersum {
    static Scanner sc = new Scanner(System.in);
    int arr[][], n, m, i, j, s = 0;

    outersum(int nn, int mm) {
        n = nn;
        m = mm;
        arr = new int[n][m];
    }

    void input() {
        System.out.println("Enter the elements : ");
        for (i = 0; i < n; i++) {
            for (j = 0; j < m; j++) {
                arr[i][j] = sc.nextInt();
            }
        }
    }

    void sumouter() {
        for (i = 0; i < n; i++) {
            for (j = 0; j < m; j++) {
                if (i == 0 || j == 0 || i == n - 1 || j == m - 1) {
                    s = s + arr[i][j];
                }
            }
        }
    }

    void display() {
        System.out.println("The Sum Of the Boundary elements are : " + s);
    }

    public static void main(String args[]) {
        System.out.println("Enter the Dimension : ");
        int n1 = sc.nextInt();
        int m1 = sc.nextInt();
        outersum obj = new outersum(n1, m1);
        obj.input();
        obj.sumouter();
        obj.display();
    }
}
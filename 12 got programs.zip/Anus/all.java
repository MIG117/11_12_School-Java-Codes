class all
{
    int rev=0;
    int reverse(int x){
        while(x>0)
        {
            int d=x%10;
            x=x/10;

            rev=rev*10+d;
        }
        return rev;
    }
}
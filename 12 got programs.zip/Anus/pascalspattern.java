import java.util.*;
class pascalspattern
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,i,j,k=1,a;
        System.out.println("Enter the Limit");
        n=sc.nextInt();
        for(i=0;i<n;i++)
        {
            for(a=n; a>i; a--)
            {
                System.out.print(" ");
            }
            k = 1;
            for(j=0;j<=i;j++)
            {
                System.out.print(k+ " ");
                k = k * (i - j) / (j + 1);
            }
            System.out.println();
        }
    }
}
 
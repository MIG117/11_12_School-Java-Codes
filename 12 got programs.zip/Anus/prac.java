import java.util.*;
class prac
{
    static Scanner sc = new Scanner(System.in);
    int i, j, k, n, sum = 0, sum1 = 0,c = 0;

    void input()
    {
        System.out.print("Enter the number : ");
        n=sc.nextInt();
    }

    int prime(int i)
    {
        for(j=1;j<=i;j++)
        {
            if(i%j==0)
            {
                c++;
            }
        }
        if(c==2)
            return i;
        else
            return 0;
    }

    boolean primed(int i)
    {
        for(j=1;j<=i;j++)
        {
            if(i%j==0)
            {
                c++;
            }
        }
        if(c==2)
            return true;
        else
            return false;
    }

    void calculate()
    {
        int cpy = n;
        i=2;
        while(i>n)
        {
            if(n%i==0)
            {
                int cpy2=i;
                int m=i;
                int p =i;
                if(primed(m))
                {
                    if(anas.count(p)==1)
                    {
                        System.out.println(p);
                        sum=sum+i;
                        System.out.println(sum);
                    }
                    else
                    {
                        System.out.println(cpy2);
                        while(cpy2>0)
                        {
                            int d=cpy2%10;
                            sum = sum + d;
                            System.out.println(sum);
                            cpy2=cpy2/10;
                        }
                    }
                }
            }
            i++;
        }
        System.out.println(sum);
        while(cpy>0)
        {
            int d=cpy%10;
            sum1 = sum1 + d;
            cpy=cpy/10;
        }
        System.out.println(sum1);
        if(sum==sum1)
            System.out.println("Smith Number");
        else
            System.out.println("Not Smith Number");
    }

    public static void main()
    {
        prac p = new prac();
        p.input();
        p.calculate();
    }
}
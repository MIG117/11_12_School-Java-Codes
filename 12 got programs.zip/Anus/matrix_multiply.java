import java.util.*;

class matrix_multiply
{
    static Scanner sc = new Scanner(System.in);
    int n,m,p,q,i,j,k,sum=0,arr1[][],arr2[][],arr3[][];

    matrix_multiply(int nn,int mm,int pp,int qq)
    {
        p=pp;
        q=qq;
        n=nn;
        m=mm;
        arr1=new int [n][m];
        arr2=new int [p][q];
        arr3=new int [n][q];
    }

    void input()
    {
        System.out.println("Enter the Elements of matrix 1 : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr1[i][j] = sc.nextInt();
            }
        }

        System.out.println("Now, Enter the Elements of matrix 2 : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr2[i][j] = sc.nextInt();
            }
        }
    }

    void multiply()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<p;j++)
            {
                for(k=0;k<q;k++)
                {
                    sum = sum + arr1[i][k]*arr2[k][j];
                }
                arr3[i][j] = sum;
                sum = 0;
            }
        }
    }

    void display()
    {
        System.out.println("Multiplied Matrix : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr3[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main()
    {
        System.out.println("NOTE : The Dimensions of both the matrix must be same and matrix type must be square!!!");
        System.out.println("Enter the Dimensions of matrix 1 : ");
        int n1 = sc.nextInt();
        int m1 = sc.nextInt();
        System.out.println("Enter the Dimensions of matrix 2 : ");
        int p1 = sc.nextInt();
        int q1 = sc.nextInt();
        if(m1!=p1)
        {
            System.out.println("The Matrices Cant be Multiplied!!!");
        }
        else
        {
            matrix_multiply done = new matrix_multiply(n1,m1,p1,q1);
            done.input();
            done.multiply();
            done.display();
        }
    }
}

import java.util.*;
class jumble
{
    static Scanner sc = new Scanner (System.in);
    int i,j,n,m,k,l,o,arr[][];

    jumble(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr = new int[n][m];
    }

    void input()
    {
        System.out.println("Enter the Values of the Matrix : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j]=sc.nextInt();
            }
        }
    }

    void Jumble()
    {
        for(i=0;i<n;i++)
        {
            for(j=1;j<m-2;j++)
            {
                for(o=0;o<n-2;o++)
                {

                    k=arr[i][o];
                    arr[i][o] = arr[i][o+2];
                    arr[i][o+2]=k;

                    l=arr[i][j-1];
                    arr[i][j-1]= arr[i][j+2];
                    arr[i][j+2] = l;
                }
            }
        }
    }

    void display()
    {
        System.out.println("JUMBLED");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }

    public static void main()
    {
        System.out.println("ENTER THE DIMENSIONS");
        int n1=sc.nextInt();
        int m1=sc.nextInt();
        if(m1<4)
            System.out.println("NOT VALID VALUE OF J");
        else
        {
            jumble obj = new jumble(n1,m1);
            obj.input();
            obj.Jumble();
            obj.display();
        }
    }
}

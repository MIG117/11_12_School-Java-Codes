import java.util.*;
class automorphic_range
{
    static Scanner sc = new Scanner(System.in);
    int n,m;
    void input()
    {
        System.out.println("Enter the value of m :");
        m=sc.nextInt();
        System.out.println("Enter the value of n :");
        n=sc.nextInt();
    }

    boolean  Check_Automorphic(int x)
    {
        int sq;
        String str_x,square;
        sq=x*x;
        str_x=Integer.toString(x);
        square = Integer.toString(sq);
        if(square.endsWith(str_x))
            return true;
        else
            return false;
    }

    void show()
    {
        automorphic_range obj = new automorphic_range();
        int i;
        boolean c;
        System.out.println("Automorphic numbers between "+m+" and "+n+" are :");
        for(i=m;i<=n;i++)
        {
            c=obj.Check_Automorphic(i);
            if(c==true)
                System.out.println(i);
        }
    }

    public static void main()
    {
        automorphic_range obj = new automorphic_range();
        obj.input();
        obj.show();
    }
}
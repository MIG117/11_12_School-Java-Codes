import java.util.*;
public class plusname
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,k,l;
        String n;
        System.out.println("Enter Your Name");
        n=sc.nextLine();
        l=n.length();
        for(i=0;i<=l;i++)
        {
            System.out.println(" ");
        }
        for(i=0;i<=l;i++)
        {
            System.out.print(" ");
        }
        for(i=0;i<=l;i++)
        {
            System.out.println(i);
        }
    }
}
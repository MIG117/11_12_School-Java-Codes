import java.util.*;

class conschange
{
    static Scanner sc = new Scanner(System.in);
    int len;
    String word,shiftcons="",changeword="",wrd2="",wrd1="";

    conschange()
    {
        word =" ";
        len=0;
    }

    void readword()
    {
        System.out.print("Enter the word : ");
        word = sc.next();
        word=word.toLowerCase();
    }

    void shiftcons()
    {
        len=word.length();
        for(int i=0;i<len;i++)
        {
            char ch=word.charAt(i);
            if(ch!='a'&&ch!='e'&&ch!='i'&&ch!='o'&&ch!='u')
            {
                wrd1=wrd1+ch;
            }
            else
            {
                wrd2=wrd2+ch;
            }
        }
        shiftcons=wrd1+wrd2;
    }

    void changeword()
    {
        /*len=word.length();
        for(int i=0;i<len;i++)
        {
            char ch=word.charAt(i);
            if(ch!='a'&&ch!='e'&&ch!='i'&&ch!='o'&&ch!='u')
            {
                wrd1=wrd1+ch;
            }
            else
            {
                wrd2=wrd2+ch;
            }
        }*/
        wrd1=wrd1.toUpperCase();
        changeword=wrd1+wrd2;
    }

    void display()
    {
        System.out.println("shiftcons : "+shiftcons);
        System.out.println("changeword : "+changeword);
    }

    public static void main()
    {
        conschange ob= new conschange();
        ob.readword();
        ob.shiftcons();
        ob.changeword();
        ob.display();
    }
}
import java.util.*;
class binhex
{
    static Scanner sc = new Scanner(System.in);
    int n,i,j,d;
    String b="",hex="";

    binhex()
    {
        b="";
        i=0;
        j=0;
    }

    String binary(int n)
    {
        while(n>0)
        {
            d=n%2;
            n=n/2;
            b = d + b;
        }
        return b;
    }

    String hexadecimal(int n)
    {
        String str = binary(n),st;
        int u=0,l=0,len,d,v=0,c=0;
        len=str.length();
        while(len%4!=0)
        {
            str="0"+str;
            len=str.length();
        }
        l=len;
        u=l-4;
        while(len>3)
        {
            st=str.substring(u,l);
            str=str.substring(0,u);
            len=str.length();
            j=Integer.parseInt(st);
            l=len;
            u=l-4;
            while(j>0)
            {
                d=j%10;
                j=j/10;
                v=(d*(int)Math.pow(2,c)) + v;
                c++;
            }
            c=0;
            if(v==10)
            {
                hex = "A" + hex;
                v=0;
            }
            else if(v==11)
            {
                hex = "B" + hex;
                v=0;
            }
            else if(v==12)
            {
                hex = "C" + hex;
                v=0;
            }
            else if(v==13)
            {
                hex = "D" + hex;
                v=0;
            }
            else if(v==14)
            {
                hex = "E" + hex;
                v=0;
            }
            else if(v==15)
            {
                hex = "F" + hex;
                v=0;
            }
            else
            {
                hex = Integer.toString(v) + hex;
                v=0;
            }
        }
        return hex;
    }

    public static void main()
    {
        binhex x = new binhex();
        System.out.println("1| Decimal to Binary Equivalent.");
        System.out.println("2| Decimal to Hexadecimal Equivalent");
        System.out.print("Enter your choice : ");
        int ch = sc.nextInt();
        switch(ch)
        {
            case 1:
            System.out.print("Enter a Decimal Number : ");
            int n = sc.nextInt();
            System.out.println("Binary Equivalent : "+x.binary(n));
            break;
            
            case 2:
            System.out.print("Enter a Decimal Number : ");
            int n1 = sc.nextInt();
            System.out.println("Hexadecimal Equivalent : "+x.hexadecimal(n1));
            break;
            
            default:
            System.out.println("Wrong choice");
            break;
        }
    }
}
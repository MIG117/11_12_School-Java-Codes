import java.util.*;
class Extrac
{
    public static void main()
    {
        Scanner sc = new Scanner (System.in);
        String str,str1="",cpy;
        int n,i,j;
        char c;
        
        System.out.println("Enter your to PAlindrome Check  : ");
        str=sc.next();
        cpy=str;
        n=str.length();
        for(i=0;i<n;i++)
        {
            c=str.charAt(i);
            str1 = c+str1;
        }
        if(str1.equals(cpy))
        {
            System.out.print("PALINDROME");
        }
        else
        {
            System.out.println("SORRY !!! IT WAS NOT PALINDROME ");
        }
    }
}

import java.util.*;
public class Strings
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        String n;
        int a,i,c=0;
        char ch;
        System.out.println("Enter the String");
        n=sc.next();
        a=n.length();
        for(i=0;i<a;i++)
        {
            c=c+1;
        }
        System.out.println("The Number of Characters :"+c);
    }
}
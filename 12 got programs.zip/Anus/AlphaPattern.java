import java.util.*;
public class AlphaPattern
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,i,j,k;
        System.out.println("Enter the limit to convert into Alphabetical Pattern");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(k=i;k<n;k++)
            {
                System.out.print(" ");
            }
            for(j=i;j>=1;j--)
            {
                System.out.print((char)(96+j));
            }
            System.out.println();
        }
    }
}
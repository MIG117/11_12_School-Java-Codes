import java.util.*;
class Array
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,max,n;
        System.out.println("Enter the size of the array: ");
        n=sc.nextInt();
        int a[]=new int [n];
        System.out.println("Enter the values of the array");
        for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        max=0;
        for(i=1;i<n;i++)
        {
            if(a[max]<a[i])
            max=i;
        }
        System.out.println("Maximum Value is : "+a[max]);
    }
}
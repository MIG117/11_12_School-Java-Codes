import java.util.*;
class Compute extends Library
{
    int d;
    double r;
    static Scanner sc = new Scanner(System.in);
    Compute(String n, String a, double np)
    {
        super(n,a,np);
    }

    void fine()
    {
        System.out.println("Enter the number of days : ");
        d=sc.nextInt();
        if(d>7)        
        {
            d=d-7;
            if(d>=1&&d<=5)
                r=d*2;
            else if(d>5&&d<=10)
                r=d*3;
            else if(d>10)
                r=d*5;
        }
    }
    
    void display()
    {
        show();
        System.out.println("No. of Days : "+d);
        System.out.println("Fine : "+r);
        System.out.println("Total Amount to pay : "+((0.02*p)*d)+r);
    }
}
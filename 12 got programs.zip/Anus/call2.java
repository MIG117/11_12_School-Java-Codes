import java.util.*;
class call2
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Name of the Book : ");
        String n=sc.next();
        System.out.println("Enter the Author of the Book : ");
        String au=sc.next();
        System.out.println("Enter the Price of the Book : ");
        int pr = sc.nextInt();
        Compute cr = new Compute(n,au,pr);
        cr.fine();
        cr.display();
    }
}
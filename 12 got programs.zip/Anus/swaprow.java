import java.util.*;
class swaprow
{
    static Scanner sc= new Scanner(System.in);
    int arr[][],i,j,k,n,m,o;

    void input()
    {
        System.out.print("Enter the value of n :");
        n=sc.nextInt();
        System.out.print("Enter the value of m : ");
        m=sc.nextInt();
        arr=new int[n][m];
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j]=sc.nextInt();
            }
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }
    }

    void swap()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                k=arr[0][j];
                arr[0][j]=arr[n-1][j];
                arr[n-1][j]=k;
            }
            k=0;
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                o=arr[i][0];
                arr[i][0]=arr[i][m-1];
                arr[i][m-1]=o;
            }
            o=0;
        }
    }

    void display()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }
    }

    public static void main()
    {
        swaprow s1=new swaprow();
        s1.input();
        s1.swap();
        s1.display();
    }
}
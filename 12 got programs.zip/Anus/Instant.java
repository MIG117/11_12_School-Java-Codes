import java.util.*;
class Instant
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,n,a,d,s=0,s2=0;
        System.out.println("Enter the Number");
        n=sc.nextInt();
        while (n>0)
        {
            d=n%10;
            n=n/10;
            if(d%2==0)
            s=s+d;
            else
            s2=s2+d;
        }
        if(s==s2)
        System.out.println("The Number is Instant");
        else
        System.out.println("The Number is not Instant");
    }
}
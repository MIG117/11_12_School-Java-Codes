import java.util.*;
public class LargestNumber
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,n,d,l=0;
        System.out.println("Enter the Number");
        n=sc.nextInt();
        while(n>0)
        {
            d=n%10;
            n=n/10;
            if(l<d)
            l = d;
        }
        System.out.println("The Largest Number = "+l);
        }
    }
import java.util.*;
public class triangles
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in); 
        int i,j,n,ch;
        System.out.println("#*#TRIANGLES#*#");
        System.out.println("1.Triangle");
        System.out.println("2.INVERTED TRIANGLE");
        System.out.println("Enter your Choice");
        ch = sc.nextInt();
        switch(ch)
        {
            case 1:
            System.out.println("Enter the Limit");
            n=sc.nextInt();
            for(i=1;i<=n;i++)
            {
                for(j=1;j<=i;j++)
                {
                    System.out.print(i);
                }
                System.out.println();
            }
            break;
            case 2:
            System.out.println("Enter the limit");
            n=sc.nextInt();
            for(i=n;i>=1;i--)
            {
                for(j=1;j<=i;j++)
                {
                    System.out.print(i);
                }
                System.out.println();
            }
            break;
            default:
            System.out.print("WRONG CHOICE");
        }
    }
}
import java.util.*;
public class Yourname
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        String n;
        System.out.println("Enter your Name");
        n = sc.nextLine();
        System.out.println("Your Name is : "+n);
    }
}
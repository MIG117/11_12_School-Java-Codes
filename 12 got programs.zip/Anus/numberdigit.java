//wap to input no. and print whether the product of digit of 1 no. is equal to the digit of 2 no
import java.util.*;
public class numberdigit
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,n,p=1,d;
        System.out.println("Enter 2 numbers");
        n=sc.nextInt();
        i=sc.nextInt();
        while(n>0)
        {
            d=n%10;
            n=n/10;
            p=p*d;
        }
        if(p==i)
            System.out.println("The product of digits of Numbers are Equal");
        else
            System.out.println("The product of digits of Numbers are  Not Equal");
    }
}
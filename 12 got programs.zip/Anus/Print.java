import java.util.*;
public class Print
{
    public static void main()
    {
        Scanner sc = new Scanner (System.in);
        int a;
        System.out.println("Enter the limit");
        a=sc.nextInt();
        for(a=1;a<=10;a++);
        System.out.print(a);
    }
}


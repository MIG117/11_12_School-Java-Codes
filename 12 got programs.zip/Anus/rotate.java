import java.util.*;
class rotate
{
    int arr[][],arr1[][],i,j,n,m;
    static Scanner sc = new Scanner(System.in);

    rotate(int nn,int mm)
    {
        n=nn;
        m=mm;
        arr=new int[n][m];
        arr1=new int[n][m];
    }

    void input()
    {
        System.out.println("Enter the elements : ");
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
    }

    void rotate_90()
    {
        int c=m-1,k=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                arr1[i][j]=arr[c--][i];
            }
            k++;
            c=m-1;
        }

    }

    void display()
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                System.out.print(arr1[i][j]+" ");
            }
            System.out.println();
        }
    }

    public static void main()
    {
        System.out.println("Enter the dimensions for a square matrix : ");
        int n1=sc.nextInt();
        int m1 = sc.nextInt();
        if(n1!=m1)
            System.out.println("ERROR");
        else
        {
            rotate r = new rotate(n1,m1);
            r.input();
            r.rotate_90();
            r.display();
        }
    }
}
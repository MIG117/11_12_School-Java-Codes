import java.util.*;
import java.io.*;
class atm
{
    static Scanner sc= new Scanner(System.in);
    int i,j,n,k;
    String str1;
    void Pin()
    {
        System.out.print("Enter your Unique Bank Number(format : ANABNK012345) : ");
        str1 = sc.next();
        System.out.print("Enter your 4 digit pin : ");
        n=sc.nextInt();
        int len = anas.count(n);
        int len1 = str1.length();
        //System.out.print(len1);
        String st = str1.substring(0,6);
        //System.out.println(st);
        String str = "Code : "+Integer.toString(n);
        if(st.compareTo("ANABNK")==0&&len1==12)
        {
            if(len==4)
            {
                str1 = "log-in ID : "+str1;
                System.out.println("Code Accepted...");
                try {
                    //Whatever the file path is.
                    File statText = new File("E:\\pin.txt");
                    Scanner sc = new Scanner(statText);
                    FileReader r = new FileReader(statText);
                    FileOutputStream is = new FileOutputStream(statText);
                    OutputStreamWriter osw = new OutputStreamWriter(is);    
                    Writer w = new BufferedWriter(osw);
                    w.write("BANK");
                    /*while(sc.hasNextLine())
                    {
                        w.write(r.read()+"    {"+str1+"   "+str+"}__");
                        w.close();
                    }*/
                } catch (IOException e) {
                    System.out.println("Problem writing to the file pin.txt");
                }
            }
            else
            {
                System.out.println("Code doesn't match the required criteria!!!");
            }
        }
        else
        {
            System.out.println("Log-In ID doesn't match the required criteria!!!");
        }
    }

    void login()
    {
        try
        {
            File file = new File("E:\\pin.txt");
            Scanner sc = new Scanner(file);
            System.out.print("Enter your Unique Bank Number(format : ANABNK012345)");
            String str1 = sc.nextLine();
            System.out.print("Enter your 4 digit pin : ");
            n=sc.nextInt();
            while (sc.hasNextLine())
            {
                System.out.println(sc.nextLine()); 
                if(str1==str1)
                {
                }
            }
        }catch(IOException e)
        {
            System.out.println("Problem writing to the file pin.txt");
        }
    }

    void Main()
    {

    }

    public static void main()
    {
        atm pin = new atm();
        System.out.println("$$$$  W E L C O M E   T O   A N A S   B A N K  $$$$");
        System.out.println("1. Open a Bank Account");
        System.out.println("2. Log-in to Existing Account");
        int ch = sc.nextInt();
        switch(ch)
        {
            case 1:
            pin.Pin();
            break;

            case 2:
            break;

            default:
            System.out.println("SORRY!!! Wrong Choice...");
        }
    }
}
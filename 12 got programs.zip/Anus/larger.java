import java.util.*;
public class larger
{
    public  static void main()
    {
        Scanner sc = new Scanner(System.in);
        int a,b,c,x,z;
        System.out.println("Enter Three Numbers");
        a=sc.nextInt();
        b=sc.nextInt();
        c=sc.nextInt();
        x=Math.max(a,b);
        z=Math.min(x,c);
        System.out.println("The Second Largest Number : "+z);
    }
}
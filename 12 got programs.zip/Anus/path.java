import java.util.*;
class path
{
    static Scanner sc = new Scanner(System.in);
    int i,j,len,k,n;
    String str;

    void input()
    {
        System.out.print("Enter the Path : ");
        str=sc.nextLine();

    }

    void Cutting()
    {
        len=str.length();
        for(i=0;i<len;i++)
        {
            if(str.charAt(i)=='.')
            {
                k=str.indexOf(".");
                n=str.lastIndexOf("/");
                System.out.println("Path : "+str.substring(0,n));
                System.out.println("File Name : "+str.substring(n+1,k));
                System.out.println("Extension : "+str.substring(k+1,len));
            }
        }
    }

    public static void main()
    {
        path p1=new path();
        p1.input();
        p1.Cutting();
    }
}
import java.util.*;

class Swap {
    static Scanner sc = new Scanner(System.in);
    int arr[][], cpy[][], n, m, i, j;

    Swap(int nn, int mm) {
        n = nn;
        m = mm;
        arr = new int[n][m];
        cpy = new int[n][m];
    }

    void input() {
        System.out.println("Enter The ELEMENTS : ");
        for (i = 0; i < n; i++) {
            for (j = 0; j < m; j++) {
                arr[i][j] = sc.nextInt();
                cpy[i][j] = arr[i][j];
            }
        }
    }

    void swaping() {
        for (i = 0; i < n; i++) {
            int t = arr[0][i];
            arr[0][i] = arr[n - 1][i];
            arr[n - 1][i] = t;
        }
    }

    void display() {
        System.out.println("ORIGINAL MATRIX : ");
        for (i = 0; i < n; i++) {
            for (j = 0; j < m; j++) {
                System.out.print(cpy[i][j]);
            }
            System.out.println();
        }
        System.out.println("SWAPPED MATRIX : ");
        for (i = 0; i < n; i++) {
            for (j = 0; j < m; j++) {
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        System.out.println("Enter the Dimensions : ");
        int n1 = sc.nextInt();
        int m1 = sc.nextInt();
        if (n1 > 3 && n1 < 10 && m1 > 3 && m1 < 10) {
            Swap obj = new Swap(n1, m1);
            obj.input();
            obj.swaping();
            obj.display();
        } else {
            System.out.println("ERROR!!! RE-ENTER : ");
            n1 = sc.nextInt();
            m1 = sc.nextInt();
        }
    }
}
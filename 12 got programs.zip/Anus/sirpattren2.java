import java.util.*;
public class sirpattren2
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,k,n;
        System.out.println("Enter the Limit");
        n=sc.nextInt();
        for(i=1;i<=n;i++)
        {
            for(k=i;k<n;k++)
            {
                System.out.print("  ");
            }
            for(j=1;j<2*i;j++)
            {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
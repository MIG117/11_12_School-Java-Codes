import java.util.*;
public class Report
{
    String name;
    int stand,regn,m,m10,m1,m2,m3,m4,m5,m6,m7,m8,m9,per;
    double percent;
    char sec;
    
    void input()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Name of the Student");
        name = sc.nextLine();
        System.out.println("Enter the Class of "+name);
        stand = sc.nextInt();
        System.out.println("Enter the Section of "+name);
        sec = sc.next().charAt(0);
        System.out.println("Enter the Registration Number of "+name);
        regn = sc.nextInt();
        System.out.println("Enter the marks of "+name+" for Subject 1");
        m = sc.nextInt();
        if(m<=100)
        m1 = m;
        else
        System.out.println("Wrong Marks of Student"+name);
        System.out.println("Enter the marks of "+name+" for Subject 2");
        m = sc.nextInt();
        if(m<=100)
        m2 = m;
        else
        System.out.println("Wrong marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 3");
        m = sc.nextInt();
        if(m<=100)
        m3 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 4");
        m = sc.nextInt();if(m<=100)
        m4 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 5");
        m = sc.nextInt();
        if(m<=100)
        m5 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 6");
        m = sc.nextInt();
        if(m<=100)
        m6 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 7");
        m = sc.nextInt();
        if(m<=100)
        m7 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 8");
        m = sc.nextInt();
        if(m<=100)
        m8 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 9");
        m = sc.nextInt();
        if(m<=100)
        m9 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
        System.out.println("Enter the marks of "+name+" for Subject 10");
        m = sc.nextInt();
        if(m<=100)
        m10 = m;
        else
        System.out.println("Wrong Marks of Student "+name);
    }
    
    void compute()
    {
        per = m1+m2+m4+m4+m5+m6+m7+m8+m9+m10;
        percent= per/1000*100;
    }
    
    void display()
    {
        System.out.println("Name\tClass\tSection\tRegn No.\tSubject 1\tSubject 2\tSubject 3\tSubject 4\tSubject 5\tSubject 6\tSubject 7\tSubject 8\tSubject 9\tSubject 10\tPercentage");
        System.out.println(name+"\t"+stand+"\t"+sec+"\t"+regn+"\t\t"+m1+"\t\t"+m2+"\t\t"+m4+"\t\t"+m4+"\t\t"+m5+"\t\t"+m6+"\t\t"+m7+"\t\t"+m8+"\t\t"+m9+"\t\t"+m10+"\t\t"+percent);
    }
    
    public static void main()
    {
        Report ob = new Report();
        ob.input();
        ob.compute();
        ob.display();
    }
}
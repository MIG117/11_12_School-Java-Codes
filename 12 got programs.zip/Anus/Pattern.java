import java.util.*;
public class Pattern
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,n;
        System.out.println("Enter the limit");
        n=sc.nextInt();
        for(i=n;i>=1;i--)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(i);
            }
            System.out.println();
        }
    }
}
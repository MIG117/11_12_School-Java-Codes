import java.util.*;
public class  digitfrequency
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,c,x,n;
        System.out.println("Enter the Numbber");
        n=sc.nextInt();
        c=0;
        x=n;
        while(x>0)
        {
            if(n==x%10)
            c++;
            x=x/10;
        }
        if(c>0)
        System.out.println(n+"i"+c);
    }
}
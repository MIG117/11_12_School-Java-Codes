import java.util.*;
class Library
{
    String name, author;
    double p;
    
    Library(String n, String a, double np)
    {
        name=n;
        author=a;
        p=np;
    }
    
    void show()
    {
        System.out.println("Name of the Book : "+ name);
        System.out.println("Author of the Book : "+ author);
        System.out.println("Price of the Book : "+ p);
    }
}
import java.util.*;

public class first {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Hello World");
        System.out.print("GIve Input : ");
        int n = sc.nextInt();
        System.out.println("SQUARE : " + (n * n));
    }
}
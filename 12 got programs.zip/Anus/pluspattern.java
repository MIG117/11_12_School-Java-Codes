import java.util.*;

class pluspattern
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,j,n,k;

        System.out.println("The number must not be a ODD number!!!");
        System.out.print("Enter the Limit : ");
        n=sc.nextInt();
        if(n%2==1)
        {
            System.out.println("ERROR!!Seems like u missed the Warninng...");
        }
        else
        {
            for(i=1;i<2*n-1;i++)
            {
                for(j=1;j<2*n-1;j++)
                {
                    if(j==(2*n-1)/2)
                        System.out.print("* ");
                    else if(i!=(2*n-1)/2)
                        System.out.print(" ");
                }
                if(i==(2*n-1)/2)
                    System.out.print("* ");
                else
                    System.out.print(" ");
                System.out.println();
            }
        }
    }
}
import java.util.*;
public class LinearSearch
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,p=-1,s;
        int a[]=new int [10];
        System.out.println("Enter the values of the array");
        for(i=0;i<10;i++)
        {
            a[i]=sc.nextInt();
        }
        System.out.println("Enter the value to search: ");
        s=sc.nextInt();
        for(i=1;i<10;i++)
        {
            if(a[i] == s)
            {
                p=i+1;
                break;
            }
        }
        if(p>-1)
        System.out.println("The element is at position :"+p);
        else
        System.out.println("The element is not present");
    }
}
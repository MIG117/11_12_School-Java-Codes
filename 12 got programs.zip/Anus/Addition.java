import java.util.*;

class Addition
{
    boolean check(String s)
    {
        for(int i=0;i<s.length();i++)
        {
            if(!(s.charAt(i)>='0'&&s.charAt(i)<='9'))
                return false;
        }
        return true;
    }

    int sum(int d1, int d2, int c)
    {
        return(d1+d2+c)%10;
    }

    int carry(int d1, int d2, int c)
    {
        return(d1+d2+c)/10;
    }

    void run()
    {
        Scanner sc = new Scanner(System.in);
        String n1,n2,n3="",tmp;
        int i,x1,x2,l,s,c=0,k;
        System.out.print("Enter 2 Numbers : ");
        n1=sc.next();
        n2=sc.next();
        if(!check(n1)||!check(n2))
        {
            System.out.println("The input is not right. Run again...");
            return;
        }
        if(n1.length()>n2.length())
        {
            tmp=n1;
            n1=n2;
            n2=tmp;
        }
        l=n1.length();
        k=n2.length()-1;
        for(i=l-1;i>=0;i--)
        {
            x1=n1.charAt(i)-48;
            if(k>=0)
                x2=n2.charAt(k)-48;
            else
                x2=0;
            s=sum(x1,x2,c);
            k--;
            n3=s+n3;
            c=carry(x1,x2,c);
        }
        if(c!=0)
            n3 = c+n3;
        System.out.println("Output -->"+n1+" + "+n2+" = "+n3);
    }

    public static void main()
    {
        Addition a1 = new Addition();
        a1.run();
    }
}
